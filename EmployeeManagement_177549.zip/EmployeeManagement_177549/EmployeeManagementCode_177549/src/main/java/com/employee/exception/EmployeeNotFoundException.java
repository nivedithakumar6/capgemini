// Author:"Niveditha K"
// Created on: "24/05/2019"
// Modified on:"Nil"
// Class Name: "EmployeeNotFoundException"
// Purpose: "creating the Exceptions class to display to the employees"

package com.employee.exception;

public class EmployeeNotFoundException extends Exception {
//default constructor
	public EmployeeNotFoundException() {
		super();

	}

	public EmployeeNotFoundException(String message) {
		super(message);

	}
	 
}
