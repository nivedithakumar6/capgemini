// Author:"Niveditha K"
// Created on: "24/05/2019"
// Modified on:"Nil"
// Class Name: "IEmployeeRepo"
// Purpose: "creating the Interface of Repo"

package com.employee.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employee.bean.Employee;
//creating the repository
@Repository
public interface IEmployeeRepo extends JpaRepository<Employee, Integer> {

}
