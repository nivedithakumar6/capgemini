// Author:"Niveditha K"
// Created on: "24/05/2019"
// Modified on:"Nil"
// Class Name: "ErrorInfo"
// Purpose: "Creating the method to display url and the message"

package com.employee.exception;


public class ErrorInfo {
	private String url; 
	private String message;
	
	//Parmeterised constructor
	
	public ErrorInfo(String url, String message) {
		this.url = url;
		this.message = message;
	}
	
	//getter and setter method
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}