// Author:"Niveditha K"
// Created on: "24/05/2019"
// Modified on:"Nil"
// Class Name: "EmployeeController"
// Purpose: "Controller to perform Spring Operations"

package com.employee.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.employee.bean.Employee;
import com.employee.exception.EmployeeNotFoundException;
import com.employee.service.EmployeeServiceImpl;

@RestController
@RequestMapping("/")
public class EmployeeController {
	
	@Autowired
	EmployeeServiceImpl employeeService;
	
	//create Employee
	@RequestMapping(value = "create", method = RequestMethod.POST, 
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee  createEmployee(@RequestBody Employee employee) {
		return this.employeeService.createEmployee(employee);
	}
	
	//update employee
	@RequestMapping(value = "updateemployee", method = RequestMethod.PUT, 
			consumes = MediaType.APPLICATION_JSON_VALUE, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee updateEmployee(@RequestBody Employee employee) {
		return this.employeeService.updateEmployee(employee);
	}
	
	//delete employee by empid
	@RequestMapping(value = "deleteemployee/{empid}", method = RequestMethod.DELETE)
	public void deleteEmployee(@PathVariable int empid) throws EmployeeNotFoundException {
		Optional<Employee> employee = this.employeeService.findEmployee(empid);
		System.out.println(employee.isPresent());
		if(!employee.isPresent())
			throw new EmployeeNotFoundException("Employee Id entered doesnot exists!");
		this.employeeService.deleteEmployee(empid);
	}
	
	//view employee list
	@RequestMapping(value = "employees", method = RequestMethod.GET)
	public List<Employee> viewEmployeeList() {
		return this.employeeService.viewEmployeeList();
	}
	
	//find employee by empid
	@RequestMapping(value = "getbyid/{empid}", method = RequestMethod.GET)
	public Optional<Employee> findEmployee(@PathVariable int empid) throws EmployeeNotFoundException{
		Optional<Employee> employee = this.employeeService.findEmployee(empid);
		System.out.println(employee.isPresent());
		if(!employee.isPresent())
			throw new EmployeeNotFoundException("Employee Id entered doesnot exists!");
		return employee;
	}
	
}
