// Author:"Niveditha K"
// Created on: "24/05/2019"
// Modified on:"Nil"
// Class Name: "EmployeeServiceImpl"
// Purpose: "Implementing the Operations"

package com.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.bean.Employee;
import com.employee.repo.IEmployeeRepo;
//Creating the service
@Service
public class EmployeeServiceImpl implements IEmployeeService{
	@Autowired
	IEmployeeRepo employeeDao;
	
	//overriding the Service interface methods
	
	@Override
	public Employee createEmployee(Employee employee) {
		return this.employeeDao.save(employee);
	}
	
	@Override
	public Employee updateEmployee(Employee employee) {
		return this.employeeDao.save(employee);
	}
	
	@Override
	public void deleteEmployee(int empid) {
		this.employeeDao.deleteById(empid);
	}
	
	@Override
	public List<Employee> viewEmployeeList(){
		return this.employeeDao.findAll();
	}

	@Override
	public Optional<Employee> findEmployee(int empid){
		return this.employeeDao.findById(empid);
	}

}
