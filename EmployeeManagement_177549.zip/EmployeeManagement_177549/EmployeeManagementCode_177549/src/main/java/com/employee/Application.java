// Author:"Niveditha K"
// Created on: "24/05/2019"
// Modified on:"Nil"
// Class Name: "Application"
// Purpose: "To run the spring Application"

package com.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
