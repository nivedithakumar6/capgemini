// Author:"Niveditha K"
// Created on: "24/05/2019"
// Modified on:"Nil"
// Class Name: "IEmployeeService"
// Purpose: "Inteface of Service class"

package com.employee.service;

import java.util.List;
import java.util.Optional;

import com.employee.bean.Employee;

public interface IEmployeeService {
	
	public Employee createEmployee(Employee employee);
	public Employee updateEmployee(Employee employee);
	public void deleteEmployee(int empid);
	public List<Employee> viewEmployeeList();
	public Optional<Employee> findEmployee(int empid);

}
