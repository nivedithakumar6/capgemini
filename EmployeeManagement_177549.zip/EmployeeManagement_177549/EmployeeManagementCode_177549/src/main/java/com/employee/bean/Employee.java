// Author:"Niveditha K"
// Created on: "24/05/2019"
// Modified on:"Nil"
// Class Name: "Employee"
// Purpose: "To create the entity"

package com.employee.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EMPLOYEES")
public class Employee {
	//assigning column name
	@Column(name = "EMPID",length = 20)
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer empid;
	
	@Column(name = "NAME", nullable = true, length = 20)
    private String name;
	
	@Column(name = "DESIGNATION", nullable = true, length = 30)
    private String designation;
	
	@Column(name = "SALARY", nullable = true, length = 8)
    private Integer salary;
	
	@Column(name = "DEPTNAME", nullable = true, length = 20)
    private String deptname;

	//Creating getter and setter methods
	
	public Integer getEmpid() {
		return empid;
	}

	public void setEmpid(Integer empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public Employee() {
		super();
	}

	public Employee(Integer empid, String name, String designation, Integer salary, String deptname) {
		super();
		this.empid = empid;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
		this.deptname = deptname;
	}

	public Employee(String name, String designation, Integer salary, String deptname) {
		super();
		this.name = name;
		this.designation = designation;
		this.salary = salary;
		this.deptname = deptname;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", designation=" + designation + ", salary=" + salary
				+ ", deptname=" + deptname + "]";
	}
	
	
}
