import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListCustomerComponent } from './list-customer/list-customer.component';
import { routes } from './app-routing.module';
import { SendpromosCustomerComponent } from './sendpromos-customer/sendpromos-customer.component';
import { SendschemesCustomerComponent } from './sendschemes-customer/sendschemes-customer.component';
import { ListMerchantComponent } from './list-merchant/list-merchant.component';
import { SendpromosMerchantComponent } from './sendpromos-merchant/sendpromos-merchant.component';
import { SendschemesMerchantComponent } from './sendschemes-merchant/sendschemes-merchant.component';

@NgModule({
  declarations: [
    AppComponent,
    ListCustomerComponent,
    SendpromosCustomerComponent,
    SendschemesCustomerComponent,
    ListMerchantComponent,
    SendpromosMerchantComponent,
    SendschemesMerchantComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
