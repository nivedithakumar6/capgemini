import { Merchant } from './model/merchant.model';
import { Customer } from './model/customer.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Promos } from './model/promos.model';
import { Schemes } from './model/schemes.model';

@Injectable({
  providedIn: 'root'
})
export class CapstoreService {
  baseUrl: string='http://localhost:9999/capstore';

  constructor(private http:HttpClient) { }

  getCustomer(){
    return this.http.get<Customer[]>(this.baseUrl + '/getcustomer');
  }

  sendPromos(){
    return this.http.get<Promos[]>(this.baseUrl + '/sendpromos');
  }

  sendSchemes(){
    return this.http.get<Schemes[]>(this.baseUrl + '/sendschemes');
  }

  getMerchant(){
    return this.http.get<Merchant[]>(this.baseUrl + '/getmerchant');
  }
}
