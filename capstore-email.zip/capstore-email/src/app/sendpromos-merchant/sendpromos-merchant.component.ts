import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Promos } from '../model/promos.model';
import { CapstoreService } from '../capstore.service';

@Component({
  selector: 'app-sendpromos-merchant',
  templateUrl: './sendpromos-merchant.component.html',
  styleUrls: ['./sendpromos-merchant.component.css']
})
export class SendpromosMerchantComponent implements OnInit {

  promos: Promos[];
  constructor(private emailService: CapstoreService, private router:Router) { }
  ngOnInit() {
    this.emailService.sendPromos()
      .subscribe((data: Promos[]) => { this.promos = data; });
  }

  sendResponse(): void{
    alert("Response is bean send to admin");
      this.router.navigate(['sendpromos-merchant']);
  }

}
