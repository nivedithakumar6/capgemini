import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendpromosMerchantComponent } from './sendpromos-merchant.component';

describe('SendpromosMerchantComponent', () => {
  let component: SendpromosMerchantComponent;
  let fixture: ComponentFixture<SendpromosMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendpromosMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendpromosMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
