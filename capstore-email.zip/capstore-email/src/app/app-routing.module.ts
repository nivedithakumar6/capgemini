import { SendschemesMerchantComponent } from './sendschemes-merchant/sendschemes-merchant.component';
import { SendpromosMerchantComponent } from './sendpromos-merchant/sendpromos-merchant.component';
import { ListMerchantComponent } from './list-merchant/list-merchant.component';
import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ListCustomerComponent } from './list-customer/list-customer.component';
import { SendpromosCustomerComponent } from './sendpromos-customer/sendpromos-customer.component';
import { SendschemesCustomerComponent } from './sendschemes-customer/sendschemes-customer.component';
export const routes:Routes=[
  {path:'', component:ListCustomerComponent, pathMatch:'full'},
  {path:'list-customer',component:ListCustomerComponent},
  {path:'sendpromos-customer',component:SendpromosCustomerComponent},
  {path:'sendschemes-customer',component:SendschemesCustomerComponent},
  {path:'list-merchant',component:ListMerchantComponent},
  {path:'sendpromos-merchant',component:SendpromosMerchantComponent},
  {path:'sendschemes-merchant',component:SendschemesMerchantComponent}
]


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  declarations: []
})
export class AppRoutingModule { }