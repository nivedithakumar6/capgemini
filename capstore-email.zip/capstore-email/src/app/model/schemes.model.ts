export class Schemes{
    schemeid?:number;
    schemename?:string;
    schemecode?:string;
    schemedescription?:string
}