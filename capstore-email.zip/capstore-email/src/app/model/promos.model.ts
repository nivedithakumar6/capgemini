export class Promos{
    promoid?:number;
    promocode?:string;
    promoname?:string;
    promodescription?:string
}