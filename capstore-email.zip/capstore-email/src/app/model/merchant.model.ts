export class Merchant{
    merchantid?:number;
    merchantname?:string;
    merchantEmail?:number;
    mpromocode?:string;
    mschemecode?:string
}