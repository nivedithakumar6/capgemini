export class Customer{
    custid?:number;
    custname?:string;
    custEmail?:number;
    promocode?:string;
    schemecode?:string
}