import { Router } from '@angular/router';
import { Schemes } from './../model/schemes.model';
import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';

@Component({
  selector: 'app-sendschemes-customer',
  templateUrl: './sendschemes-customer.component.html',
  styleUrls: ['./sendschemes-customer.component.css']
})
export class SendschemesCustomerComponent implements OnInit {
  schemes: Schemes[];
  constructor(private emailService: CapstoreService, private router:Router) { }
  ngOnInit() {
    this.emailService.sendSchemes()
      .subscribe((data: Schemes[]) => { this.schemes = data; });
  }

}
