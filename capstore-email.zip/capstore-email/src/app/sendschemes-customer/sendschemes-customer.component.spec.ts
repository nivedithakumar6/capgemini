import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendschemesCustomerComponent } from './sendschemes-customer.component';

describe('SendschemesCustomerComponent', () => {
  let component: SendschemesCustomerComponent;
  let fixture: ComponentFixture<SendschemesCustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendschemesCustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendschemesCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
