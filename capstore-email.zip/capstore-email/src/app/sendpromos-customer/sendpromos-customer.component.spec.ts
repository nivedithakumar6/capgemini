import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendpromosCustomerComponent } from './sendpromos-customer.component';

describe('SendpromosCustomerComponent', () => {
  let component: SendpromosCustomerComponent;
  let fixture: ComponentFixture<SendpromosCustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendpromosCustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendpromosCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
