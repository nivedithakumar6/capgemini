import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Promos } from '../model/promos.model';
import { CapstoreService } from '../capstore.service';

@Component({
  selector: 'app-sendpromos-customer',
  templateUrl: './sendpromos-customer.component.html',
  styleUrls: ['./sendpromos-customer.component.css']
})
export class SendpromosCustomerComponent implements OnInit {

  promos: Promos[];
  constructor(private emailService: CapstoreService, private router:Router) { }
  ngOnInit() {
    this.emailService.sendPromos()
      .subscribe((data: Promos[]) => { this.promos = data; });
  }

}
