import { Router } from '@angular/router';
import { Schemes } from './../model/schemes.model';
import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';

@Component({
  selector: 'app-sendschemes-merchant',
  templateUrl: './sendschemes-merchant.component.html',
  styleUrls: ['./sendschemes-merchant.component.css']
})
export class SendschemesMerchantComponent implements OnInit {

  schemes: Schemes[];
  constructor(private emailService: CapstoreService, private router:Router) { }
  ngOnInit() {
    this.emailService.sendSchemes()
      .subscribe((data: Schemes[]) => { this.schemes = data; });
  }


  sendResponse(): void{
    alert("Response is bean send to admin");
      this.router.navigate(['sendschemes-merchant']);
  }

}
