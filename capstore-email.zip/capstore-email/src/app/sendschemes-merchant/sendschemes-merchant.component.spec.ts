import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendschemesMerchantComponent } from './sendschemes-merchant.component';

describe('SendschemesMerchantComponent', () => {
  let component: SendschemesMerchantComponent;
  let fixture: ComponentFixture<SendschemesMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendschemesMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendschemesMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
