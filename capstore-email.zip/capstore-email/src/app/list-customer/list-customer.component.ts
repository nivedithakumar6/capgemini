import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';
import { Customer } from '../model/customer.model';

@Component({
  selector: 'app-list-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.css']
})
export class ListCustomerComponent implements OnInit {
  customers: Customer[];
  constructor(private emailService: CapstoreService, private router:Router) { }
  ngOnInit() {
    this.emailService.getCustomer()
      .subscribe((data: Customer[]) => { this.customers = data; });
  }

  VerifyCustomerById(): void {
    alert("Customer verified");
      this.router.navigate(['list-customer']);
  }

  sendInvitation(): void{
    alert("Invitation Email- Welcome To Capstore, You are invited to Capstore");
      this.router.navigate(['list-customer']);
  }

  sendPromos(): void{
    this.router.navigate(['sendpromos-customer']);
  }

  sendSchemes(): void{
    this.router.navigate(['sendschemes-customer']);
  }
  displayCustomer(){
    this.router.navigate(['list-customer']);
  }

  displayMerchant(){
    this.router.navigate(['list-merchant']);
  }

}
