import { Router } from '@angular/router';
import { Merchant } from './../model/merchant.model';
import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';

@Component({
  selector: 'app-list-merchant',
  templateUrl: './list-merchant.component.html',
  styleUrls: ['./list-merchant.component.css']
})
export class ListMerchantComponent implements OnInit {

  merchants: Merchant[];
  constructor(private emailService: CapstoreService, private router:Router) { }
  ngOnInit() {
    this.emailService.getMerchant()
      .subscribe((data: Merchant[]) => { this.merchants = data; });
  }

  VerifyMerchantById(): void {
    alert("Merchant verified");
      this.router.navigate(['list-merchant']);
  }

  sendInvitation(): void{
    alert("Invitation Email- Welcome To Capstore, You are invited to Capstore");
      this.router.navigate(['list-merchant']);
  }

  sendPromos(): void{
    this.router.navigate(['sendpromos-merchant']);
  }

  sendSchemes(): void{
    this.router.navigate(['sendschemes-merchant']);
  }

  displayCustomer(){
    this.router.navigate(['list-customer']);
  }

  displayMerchant(){
    this.router.navigate(['list-merchant']);
  }

}
