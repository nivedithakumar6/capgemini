export class GameCity{
    name?:string;
    price?:number;
}