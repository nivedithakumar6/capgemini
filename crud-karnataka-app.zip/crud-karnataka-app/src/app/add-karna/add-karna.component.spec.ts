import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddKarnaComponent } from './add-karna.component';

describe('AddKarnaComponent', () => {
  let component: AddKarnaComponent;
  let fixture: ComponentFixture<AddKarnaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddKarnaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddKarnaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
