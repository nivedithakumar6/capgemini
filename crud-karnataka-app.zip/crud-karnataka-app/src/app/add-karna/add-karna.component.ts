import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { KarnatakaService } from '../service/karnataka.service';

@Component({
  selector: 'app-add-karna',
  templateUrl: './add-karna.component.html',
  styleUrls: ['./add-karna.component.css']
})
export class AddKarnaComponent implements OnInit {

  formlabel: string = 'Add Karnataka';
  constructor(private formBuilder: FormBuilder, private karnaService: KarnatakaService, private router:Router) { }

  addKarnaForm: FormGroup

  ngOnInit() {
    this.addKarnaForm = this.formBuilder.group({
      id: ['', Validators.required],
      name: ['', Validators.required],
      salary: ['', [Validators.required, Validators.maxLength(5)]],
      place: ['', Validators.required]
    });
  }

  onSubmit() {

    console.log('Karnataka details sent to server!');

    this.karnaService.createUser(this.addKarnaForm.value)

      .subscribe(data => {

        console.log("Data Saved!");
        alert("data saved!");
        window.location.reload();
      },

        error => {

          console.log("Error occured " + error);

          //alert(error);

        });

  }

}
