import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginKarnaComponent } from './login-karna.component';

describe('LoginKarnaComponent', () => {
  let component: LoginKarnaComponent;
  let fixture: ComponentFixture<LoginKarnaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginKarnaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginKarnaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
