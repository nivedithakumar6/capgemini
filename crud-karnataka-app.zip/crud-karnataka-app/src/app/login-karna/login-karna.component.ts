import { KarnatakaService } from '../service/karnataka.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-karna',
  templateUrl: './login-karna.component.html',
  styleUrls: ['./login-karna.component.css']
})
export class LoginKarnaComponent implements OnInit {

  LoginForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;

  constructor(private formBuilder: FormBuilder, private empService: KarnatakaService, private router: Router) { }


  ngOnInit() {
    this.LoginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.LoginForm.invalid) {
      return;
    }
    if (this.LoginForm.controls.email.value == 'niveditha@gmail.com' && this.LoginForm.controls.password.value == 'Nivi') {
      this.router.navigate(['list-karna']);
    }
    else {
      this.invalidLogin = true;
      alert("invalid login details");
    }
  }

}
