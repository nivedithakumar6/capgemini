import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Karnataka } from '../ModelFolder/karnataka.model';

@Injectable({
  providedIn: 'root'
})
export class KarnatakaService {
  

  baseUrl: string='http://localhost:3000/karnataka';

  constructor(private http:HttpClient, private router:Router ) { }

  getKarnataka(){
    return this.http.get<Karnataka[]>(this.baseUrl);
  }

  deleteKarnataka(id: number){
    return this.http.delete<Karnataka[]>(this.baseUrl + '/' +id);
  }
  createUser(karnataka:Karnataka){
    return this.http.post(this.baseUrl,karnataka);
  }
  getKarnatakaById(id:number){
    return this.http.get<Karnataka>(this.baseUrl + '/' +id);
  }
  updateKarnataka(karnataka:Karnataka){
    return this.http.put<Karnataka>(this.baseUrl + '/' + karnataka.id ,karnataka);
  }

}
