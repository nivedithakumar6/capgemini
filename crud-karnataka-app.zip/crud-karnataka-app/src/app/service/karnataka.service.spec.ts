import { TestBed } from '@angular/core/testing';

import { KarnatakaService } from './karnataka.service';

describe('KarnatakaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: KarnatakaService = TestBed.get(KarnatakaService);
    expect(service).toBeTruthy();
  });
});
