import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListKarnaComponent } from './list-karna.component';

describe('ListKarnaComponent', () => {
  let component: ListKarnaComponent;
  let fixture: ComponentFixture<ListKarnaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListKarnaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListKarnaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
