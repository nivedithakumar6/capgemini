import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Karnataka } from '../ModelFolder/karnataka.model';
import { KarnatakaService } from '../service/karnataka.service';

@Component({
  selector: 'app-list-karna',
  templateUrl: './list-karna.component.html',
  styleUrls: ['./list-karna.component.css']
})
export class ListKarnaComponent implements OnInit {

  karnataka: Karnataka[];
  filteredKarnataka: Karnataka[];

  _listFilter: string = '';
  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    console.log('set listFilter' + this._listFilter);
    this._listFilter = value;
    this.filteredKarnataka = this.listFilter ? this.performFilter(this.listFilter) : this.karnataka;
  }


  performFilter(filterBy: string): Karnataka[] {
    return this.karnataka.filter((karnataka: Karnataka) =>
      karnataka.name.toLocaleLowerCase().indexOf(filterBy) !== -1 || karnataka.id == +filterBy
    );
  //return this.karnataka.filter(this.myFilter.bind(this));
  }

   myFilter (karnataka: Karnataka)  : boolean {
    return karnataka.name.toLocaleLowerCase().indexOf(this.listFilter.toLocaleLowerCase()) !== -1 || karnataka.id == +this.listFilter;
  }



  constructor(private karnaService: KarnatakaService, private router: Router) { }
  ngOnInit() {
    this.karnaService.getKarnataka()
      .subscribe((data: Karnataka[]) => {
      this.karnataka = data;
        //alert(data);
        this.filteredKarnataka = this.karnataka;
      });
  }

  deleteKarnataka(karnataka: Karnataka): void {
    this.karnaService.deleteKarnataka(karnataka.id)
      .subscribe(data => {

        this.karnataka = this.karnataka.filter(karna => karna != karnataka);
      })
  }
  editKarnataka(karnataka: Karnataka): void {
    localStorage.removeItem('editKarnaId');
    localStorage.setItem('editKarnaId', karnataka.id.toString());
    this.router.navigate(['edit-karna']);
  }

}
