import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { KarnatakaService } from '../service/karnataka.service';

@Component({
  selector: 'app-edit-karna',
  templateUrl: './edit-karna.component.html',
  styleUrls: ['./edit-karna.component.css']
})
export class EditKarnaComponent implements OnInit {

  formlabel: string = 'Edit Karnataka';
  empformbtn: string = 'Update';
  constructor(private formBuilder: FormBuilder, private karnaService: KarnatakaService,private router:Router) { }

  editKarnaForm: FormGroup

  ngOnInit() {
    this.editKarnaForm = this.formBuilder.group({
      id: [],
     name: ['', Validators.required],
      salary: ['', [Validators.required, Validators.maxLength(9)]],
      place: ['', Validators.required]
    });

    let karnaid = localStorage.getItem('editKarnaId');
    if (+karnaid > 0) {
      this.karnaService.getKarnatakaById(+karnaid).subscribe(data => {
        this.editKarnaForm.patchValue(data);
      })
      
    }
  }

  onUpdate() {
    console.log('Updating record.');
    this.karnaService.updateKarnataka(this.editKarnaForm.value).subscribe(data => {
      alert("record updated");
      this.router.navigate(['list-karna']);
    },
      error => {
        alert(error);
      });
  }

}
