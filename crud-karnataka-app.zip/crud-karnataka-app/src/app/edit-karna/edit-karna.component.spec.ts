import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditKarnaComponent } from './edit-karna.component';

describe('EditKarnaComponent', () => {
  let component: EditKarnaComponent;
  let fixture: ComponentFixture<EditKarnaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditKarnaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditKarnaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
