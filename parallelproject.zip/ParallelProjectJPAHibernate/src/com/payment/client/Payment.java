package com.payment.client;

import com.payment.entities.Account;
import com.payment.entities.Transaction;
import com.payment.service.IPaymentService;
import com.payment.service.PaymentServiceImpl;

public class Payment {
	
	public static void main(String[] args) {
		
		IPaymentService iserv=new PaymentServiceImpl();
		Account account=new Account();
		Transaction transaction=new Transaction();
		
//		//Create Account
//		account.setName("Niveditha");
//		account.setMobile("9019722746");
//		account.setEmail("nivi@gmail.com");
//		account.setPan("DFJPK2615L");
//		account.setType("Saving");
//		account.setBalance(10000);
//		iserv.createAccount(account);
//		System.out.println("Account Created");
		
//		//Show Balance
//		account=iserv.showBalance(1);
//		System.out.println("Balance: "+account.getBalance());
		
//		//Deposit
//		account=iserv.showBalance(1);
//		account.setBalance(15000);
//		iserv.Deposit(account);
		
		//Withdraw
//		account=iserv.showBalance(1001);
//		account.setBalance(5000);
//		iserv.Withdraw(account);
		
		//add transaction
//		transaction.setAccId(1000);
//		transaction.setBalance(15000);
//		transaction.setTypeTrans("Deposit");
//		iserv.addTransaction(transaction);
//		System.out.println("Transaction Added");
		
		//print Transaction
		transaction=iserv.printTransaction(2);
		System.out.println("Transaction ID: "+transaction.getTransId());
		System.out.println("Account ID: "+transaction.getAccId());
		System.out.println("Balance: "+transaction.getBalance());
		System.out.println("Transaction type: "+transaction.getTypeTrans());
}
}
