package com.payment.service;

import com.payment.dao.IPaymentDao;
import com.payment.dao.PaymentDaoImpl;
import com.payment.entities.Account;
import com.payment.entities.Transaction;

public class PaymentServiceImpl implements IPaymentService {
	
	private IPaymentDao idao;
	public PaymentServiceImpl(){
		idao=new PaymentDaoImpl();
	}

	@Override
	public void createAccount(Account account) {
		idao.beginTransaction();
		idao.createAccount(account);
		idao.commitTransaction();
	}

	@Override
	public Account showBalance(int accId) {
		Account account=idao.showBalance(accId);
		return account;
	}

	@Override
	public void Deposit(Account account) {
		idao.beginTransaction();
		idao.Deposit(account);
		idao.commitTransaction();
	}

	@Override
	public void Withdraw(Account account) {
		idao.beginTransaction();
		idao.Withdraw(account);
		idao.commitTransaction();
	}

	@Override
	public void commitTransaction() {
		idao.beginTransaction();
	}

	@Override
	public void beginTransaction() {
		idao.commitTransaction();
	}

	@Override
	public void addTransaction(Transaction transaction) {
		idao.beginTransaction();
		idao.addTransaction(transaction);
		idao.commitTransaction();
	}

	@Override
	public Transaction printTransaction(int transId) {
		Transaction transaction=idao.printTransaction(transId);
		return transaction;
	}

}
