package com.payment.dao;

import javax.persistence.EntityManager;
import com.payment.entities.Account;
import com.payment.entities.Transaction;

public class PaymentDaoImpl implements IPaymentDao {
	
	private EntityManager entityManager;
	
	public PaymentDaoImpl()
	{
		entityManager=JPAUtil.getEntityManager();
	}

	@Override
	public void createAccount(Account account) {
		entityManager.persist(account);
	}

	@Override
	public Account showBalance(int accId) {
		Account account = entityManager.find(Account.class, accId);
		return account;
	}

	@Override
	public void Deposit(Account account) {
		entityManager.merge(account);
	}

	@Override
	public void Withdraw(Account account) {
		entityManager.merge(account);
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void addTransaction(Transaction transaction) {
		entityManager.persist(transaction);
	}

	@Override
	public Transaction printTransaction(int transId) {
		Transaction transaction = entityManager.find(Transaction.class, transId);
		return transaction;
	}

}
