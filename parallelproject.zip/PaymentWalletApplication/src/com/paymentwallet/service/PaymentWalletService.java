package com.paymentwallet.service;

import java.time.LocalDate;
import java.util.Collection;
import java.util.regex.Pattern;

import javax.management.openmbean.OpenDataException;

import com.paymentwallet.bean.Account;
import com.paymentwallet.bean.Transaction;
import com.paymentwallet.dao.PaymentWalletDao;
import com.paymentwallet.exception.InvalidException;

public class PaymentWalletService implements IPaymentWalletService {
	
	static PaymentWalletDao idao=null;
	static boolean res;


	private int generateAccountId(){
		int n=(int)(Math.random()*10000);
		return n;
	}
	
	private int generateTransId(){
		int m=(int)(Math.random()*1000);
		return m;
	}
	
	private LocalDate generateDate()
	{
		LocalDate date=LocalDate.now();
		return date;
	}
	
	@Override
	public int createAccount(Account accId, Transaction Trans) {
		int z=generateAccountId();
		accId.setAccId(z);
		Trans.setAccId(z);
		accId.setDate(generateDate());
		Trans.setDate(generateDate());
		Trans.setTypeTrans("Openinig Balanace");
		Trans.setTransId(generateTransId());
		idao=new PaymentWalletDao();
		return idao.createAccount(accId, Trans);
		
	}
	
	@Override
	public void showBalanace(int accId) {
		idao=new PaymentWalletDao();
		idao.showBalance(accId);
		
	}
	
	@Override
	public void deposit(int accId1, double amt,Transaction Trans) {
		Trans.setDate(generateDate());
		Trans.setTypeTrans("Deposit");
		Trans.setAccId(accId1);
		Trans.setTransId(generateTransId());
		idao=new PaymentWalletDao();
		idao.deposit(accId1, amt,Trans);
		
	}
	
	@Override
	public void withdraw(int accId2, double amt2,Transaction Trans) {
		Trans.setDate(generateDate());
		Trans.setTypeTrans("WithDraw");
		Trans.setAccId(accId2);
		Trans.setTransId(generateTransId());
		idao=new PaymentWalletDao();
		idao.withdraw(accId2, amt2,Trans);
	}


	@Override
	public void fundTransfer(int accId3, int accId4, double amt3,Transaction Trans1, Transaction Trans2) {
		Trans1.setDate(generateDate());
		Trans2.setDate(generateDate());
		Trans1.setAccId(accId3);
		Trans2.setAccId(accId4);
		Trans1.setTransId(generateTransId());
		Trans2.setTransId(generateTransId());
		idao=new PaymentWalletDao();
		idao.fundTransfer(accId3, accId4, amt3,Trans1,Trans2);
		
	}

	@Override
	public void printTransaciton(int accId5) {
		idao=new PaymentWalletDao();
		idao.printTransaciton(accId5);
		
	}
	
	@Override
	public boolean validateName(String name) throws InvalidException {
//		if(name==null || name.equals(null)){
//			throw new  InvalidException("obj is null");
//		}
		
		if(!Pattern.compile("^[A-Z][a-z]{3,}").matcher(name).find()){
			throw new InvalidException("not matching pattern");
		}
		return true;
	}

	@Override
	public boolean validateMobile(String mobile) throws InvalidException {
		if(mobile==null || mobile.equals(null)){
			throw new  InvalidException("Mobile is null");
		}
		
		if(!Pattern.compile("^[6-9]{1}[0-9]{9}").matcher(mobile).find()){
			throw new InvalidException("not matching pattern");
		}
		return true;
	}

	@Override
	public boolean validateEmail(String email) throws InvalidException {
		if(email==null || email.equals(null)){
			throw new  InvalidException("Email is null");
		}
		
		if(!Pattern.compile("^[a-z A-z 0-9 .]{3,}@gmail.com").matcher(email).find()){
			throw new InvalidException("not matching pattern");
		}
		return true;
	}

	@Override
	public boolean validateDOB(String dob) throws InvalidException {
		if(dob==null || dob.equals(null)){
			throw new  InvalidException("Date Of Birth is null");
		}
		if(!Pattern.compile("^[0-9]{1,2}[/]{1}[0-9]{1,2}[/][0-9]{4}").matcher(dob).find()){
			throw new InvalidException("not matching pattern");
		}
		return true;
	}

	@Override
	public boolean validateAddress(String address) throws InvalidException {
		if(address==null || address.equals(null)){
			throw new  InvalidException("address is null");
		}
		if(!Pattern.compile("^[A-Z a-z 0-9 ,]{4,}").matcher(address).find()){
			throw new InvalidException("not matching pattern");
		}
		return true;
	}

	@Override
	public boolean validatePan(String pan) throws InvalidException {
		if(pan==null || pan.equals(null)){
			throw new  InvalidException("pan is null");
		}
		if(!Pattern.compile("^[A-Z a-z 0-9 ,]{10}").matcher(pan).find()){
			throw new InvalidException("not matching pattern");
		}
		return true;
	}

	@Override
	public boolean validateType(String type) throws InvalidException {
		if(type==null || type.equals(null)){
			throw new  InvalidException("pan is null");
		}
		if(!((type.equalsIgnoreCase("saving")) || (type.equalsIgnoreCase("current"))))
		{
			throw new InvalidException("Not valid type ");
		}
		return true;
	}

	@Override
	public boolean validateBalance(double openbal) throws InvalidException {
		
		if(!(openbal>=500))
		{
			throw new InvalidException("Low balance");
		}
		return true;
	}



}
