package com.paymentwallet.bean;

import java.time.LocalDate;

public class Transaction {

	int accId;
	double balance;
	String typeTrans;
	int transId;
	LocalDate date;
	
	public Transaction(double balance) {
		this.balance = balance;
	}

	
	public Transaction(int accId, double balance, String typeTrans, int transId, LocalDate date) {
		super();
		this.accId = accId;
		this.balance = balance;
		this.typeTrans = typeTrans;
		this.transId = transId;
		this.date = date;
	}


	public int getTransId() {
		return transId;
	}


	public void setTransId(int transId) {
		this.transId = transId;
	}


	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Transaction() {
		
	}

	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getTypeTrans() {
		return typeTrans;
	}
	public void setTypeTrans(String typeTrans) {
		this.typeTrans = typeTrans;
	}


//	@Override
//	public String toString() {
//		return "Transaction [accId=" + accId + ", balance=" + balance + ", typeTrans=" + typeTrans + ", transId="
//				+ transId + ", date=" + date + "]";
//	}

	
	
//	public Transaction(int accId, double openbal, String typeTrans, double deposit, String withdraw,
//			String fundTransfer, LocalDate date) {
//		super();
//		this.accId = accId;
//		this.openbal = openbal;
//		this.typeTrans = typeTrans;
//		Deposit = deposit;
//		Withdraw = withdraw;
//		FundTransfer = fundTransfer;
//		this.date = date;
//	}

//	public double getDeposit() {
//		return Deposit;
//	}
//
//	public void setDeposit(double amt) {
//		Deposit = amt;
//	}
//
//	public String getWithdraw() {
//		return Withdraw;
//	}
//
//	public void setWithdraw(String withdraw) {
//		Withdraw = withdraw;
//	}
//
//	public String getFundTransfer() {
//		return FundTransfer;
//	}
//
//	public void setFundTransfer(String fundTransfer) {
//		FundTransfer = fundTransfer;
//	}

	
	
	
	}
