package com.paymentwallet.dao;

import java.util.Collection;

import com.paymentwallet.bean.Account;
import com.paymentwallet.bean.Transaction;

public interface IPaymentWalletDao {
	
	
	public void showBalance(int accId);
	public void deposit(int accId1, double amt,Transaction Trans);
	public void withdraw(int accId2, double amt2,Transaction Trans);
	public int createAccount(Account accId, Transaction Trans);
	public void fundTransfer(int accId3, int accId4, double amt3,Transaction Trans1,Transaction Trans2);
	public void printTransaciton(int accId5);
	
}
