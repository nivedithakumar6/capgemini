package com.paymentwallet.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


import com.paymentwallet.bean.Account;
import com.paymentwallet.bean.Transaction;

public class PaymentWalletDao implements IPaymentWalletDao{
	
	static Map<Integer, Account> AccountList=new HashMap<>();
	static Map<Integer, Transaction> TransactionList=new HashMap<>(); 

	@Override
	public int createAccount(Account accId,Transaction Trans) {
		
		AccountList.put(accId.getAccId(), accId);
		TransactionList.put(Trans.getTransId(), Trans);
		return accId.getAccId();
	}

	@Override
	public void showBalance(int accId) {
		Collection<Account> t=AccountList.values();
		Account r=AccountList.get(accId);
		System.out.println("Available balance: "+r.getBalance());
	}

	@Override
	public void deposit(int accId1, double amt, Transaction Trans) {
		Account r1=AccountList.get(accId1);
		double d=r1.getBalance();
		d=d+amt;
		r1.setBalance(d);
		Trans.setBalance(d);
//		Trans.setDeposit(amt);

		TransactionList.put(Trans.getTransId(), Trans);
		System.out.println("You have deposited "+amt+" on"+r1.getDate());
		System.out.println("Available Balance: "+Trans.getBalance());
//		Transaction a=TransactionList.get(accId1);
//		System.out.println("the deposaited amount is:"+a.getDeposit());
		 
	}



	@Override
	public void withdraw(int accId2, double amt2,Transaction Trans) {
		Account r1=AccountList.get(accId2);
		double d=r1.getBalance();
		d=d-amt2;
		r1.setBalance(d);
		
		
		Trans.setBalance(d);
		TransactionList.put(Trans.getTransId(), Trans);
		System.out.println("You have Withdrawn "+amt2+" on"+r1.getDate());
		System.out.println("Available Balance: "+Trans.getBalance());
		
	}

	@Override
	public void fundTransfer(int accId3, int accId4, double amt3,Transaction Trans1,Transaction Trans2) {
		Account r1=AccountList.get(accId3);
		double d1=r1.getBalance();
		Account r2=AccountList.get(accId4);
		double d2=r2.getBalance();
		Trans1.setTypeTrans("Fund deposited");
		d1=d1-amt3;
		r1.setBalance(d1);
		Trans1.setBalance(d1);
		TransactionList.put(Trans1.getTransId(), Trans1);
		System.out.println("Balance in "+accId3 +" is "+Trans1.getBalance());
		
		d2=d2+amt3;
		r2.setBalance(d2);
		Trans2.setBalance(d2);
		Trans2.setTypeTrans("Fund credited");
		TransactionList.put(Trans2.getTransId(), Trans2);
		System.out.println("Balance in "+accId4 +" is "+Trans2.getBalance());
	}

	public void printTransaciton(int accId5) {
		Collection<Transaction> tlist=TransactionList.values();
//		Transaction r=TransactionList.get(accId5);
		for(Transaction entry:tlist ) {
			if(entry.getAccId()==accId5)
			{
            System.out.println("Account No: "+entry.getAccId()+" Balance: "+entry.getBalance()+" Type Of Transaction: "+entry.getTypeTrans()+" Date: "+entry.getDate()+" Transaction Id: "+entry.getTransId());
			}
//            Transaction a=TransactionList.get(accId);
//            System.out.println("depoisted :"+a.getDeposit());
		}
		
		
		//System.out.println(p.getAccId()+" "+p.getOpenbal()+" "+p.getTypeTrans()+" "+p.getDate());
		
	}
//	public int printTransaction() {
//		
//		System.out.println("depoisted :");
//		return 0;
//		
//	}
//
//	@Override
//	public void printTransaciton() {
//		// TODO Auto-generated method stub
//		
//	}

	
	
	

}
