package com.paymentwallet.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


import com.paymentwallet.bean.Account;
import com.paymentwallet.bean.Transaction;
import com.paymentwallet.dao.IPaymentWalletDao;
import com.paymentwallet.dao.PaymentWalletDao;

public class TestPayment {
	
	IPaymentWalletDao idao=null;
	
	@Before
	public void Init()
	{
		idao=new PaymentWalletDao();
	}
	@After
	public void Terminal()
	{
		idao=null;
	}
	@Test
	public void testCreateAccount()
	{
		Account account=new Account("Niveditha","9611243213","nivi@capgemini.com","12/2/2019","Bangalore", "asdfg12345", "saving",5000d);
		Transaction trans=new Transaction(5000d);
		account.setAccId(100001);
		trans.setAccId(100001);
		int accId=idao.createAccount(account, trans);
		Assert.assertEquals(accId,100001);
	}
	
//	@Test
//	public void testShowBalance()
//	{
//		Account account=new Account();
//		account.setAccId(10001);
//		idao.showBalance(account.getAccId());
//		Assert.assertNotNull(idao);
//	}
}
