package com.demo.dao;

import org.springframework.stereotype.Repository;
import com.demo.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface PaymentDaoAccount extends JpaRepository<Account, Integer> {

}
