package com.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Account;
import com.demo.entity.Transaction;
import com.demo.service.PaymentService;

@RestController
@RequestMapping("/account")
public class paymentController {
	
	@Autowired 
	PaymentService pser;
	
	//get account
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<Account> getAccount() {
		return this.pser.getAccount();
	}
	
	//Create Account
	@RequestMapping(value="/create", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Account createAccount(@RequestBody Account account) {
		return this.pser.createAccount(account);
	}
	
	//Show Balance
	@RequestMapping(value = "/{accId}", method = RequestMethod.GET)
	public Optional<Account> showBalance(@PathVariable int accId) {
		return this.pser.showBalance(accId);
	}
	
	//Deposit
	@RequestMapping(value = "/deposit", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Account Deposit(@RequestBody Account account) {
		return this.pser.Deposit(account);
	}
	
	//Withdraw
	@RequestMapping(value = "/withdraw", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Account Withdraw(@RequestBody Account account) {
		return this.pser.Withdraw(account);
	}
		
	//Transaction Details
	
	//Get All transaction
	@RequestMapping(value = "/trans/all", method = RequestMethod.GET)
	public List<Transaction> getTransaction() {
		return this.pser.getTransaction();
	}
	
	//add Transaction
	@RequestMapping(value="/trans/create", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Transaction addTransaction(@RequestBody Transaction transaction) {
		return this.pser.addTransaction(transaction);
	}
	
	//show by transaction
	@RequestMapping(value = "/trans/{transId}", method = RequestMethod.GET)
	public Optional<Transaction> printTransaction(@PathVariable int transId) {
		return this.pser.printTransaction(transId);
	}

}
