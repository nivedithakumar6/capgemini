package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.PaymentDaoAccount;
import com.demo.dao.PaymentDaoTransaction;
import com.demo.entity.Account;
import com.demo.entity.Transaction;

@Service
public class PaymentService {
	@Autowired
	PaymentDaoAccount pdaoAcc;
	
	@Autowired
	PaymentDaoTransaction  pdaoTrans;
	
	public Account createAccount(Account account) {
		return this.pdaoAcc.save(account);
	}
	
	 public Optional<Account> showBalance(int accId) {
	        return this.pdaoAcc.findById(accId);
	}
	 
	 public Account Deposit(Account account) {
		 return this.pdaoAcc.save(account);
	 }
	 
	 public Account Withdraw(Account account) {
		 return this.pdaoAcc.save(account);
	 }
	
	public List<Account> getAccount() {
        return this.pdaoAcc.findAll();
    }
	
	//Transaction Details
	
	public List<Transaction> getTransaction() {
        return this.pdaoTrans.findAll();
    }
	
	public Transaction addTransaction(Transaction transaction) {
		return this.pdaoTrans.save(transaction);
	}
	
	public Optional<Transaction> printTransaction(int transId) {
        return this.pdaoTrans.findById(transId);
}

}

