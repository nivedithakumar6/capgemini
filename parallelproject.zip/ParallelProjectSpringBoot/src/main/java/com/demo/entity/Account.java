package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ACCOUNT")
public class Account {
	//primary code
	    @Column(name = "ACCID")
	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Integer accId;

	    @Column(name = "NAME", nullable = true, length = 20)
	    private String name;

	    @Column(name = "MOBILE", nullable = true, length = 10)
	    private String mobile;
	    
	    @Column(name = "EMAIL", nullable = true, length = 30)
	    private String email;
	    
	    @Column(name = "PAN", nullable = true, length = 10)
	    private String pan;
	    
	    @Column(name = "TYPE", nullable = true, length = 10)
	    private String type;
	    
	    @Column(name = "BALANCE", nullable = true, length = 10)
	    private Integer balance;

		

		public Integer getAccId() {
			return accId;
		}

		public void setAccId(Integer accId) {
			this.accId = accId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getMobile() {
			return mobile;
		}

		public void setMobile(String mobile) {
			this.mobile = mobile;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPan() {
			return pan;
		}

		public void setPan(String pan) {
			this.pan = pan;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public Integer getBalance() {
			return balance;
		}

		public void setBalance(Integer balance) {
			this.balance = balance;
		}

		public Account(Integer accId, String name, String mobile, String email, String pan, String type,
				Integer balance) {
			super();
			this.accId = accId;
			this.name = name;
			this.mobile = mobile;
			this.email = email;
			this.pan = pan;
			this.type = type;
			this.balance = balance;
		}

		public Account(String name, String mobile, String email, String pan, String type, Integer balance) {
			super();
			this.name = name;
			this.mobile = mobile;
			this.email = email;
			this.pan = pan;
			this.type = type;
			this.balance = balance;
		}
		
		

		public Account() {
			super();
		}

		@Override
		public String toString() {
			return "Account [accId=" + accId + ", name=" + name + ", mobile=" + mobile + ", email=" + email + ", pan="
					+ pan + ", type=" + type + ", balance=" + balance + "]";
		}

		
	
	
	

}
