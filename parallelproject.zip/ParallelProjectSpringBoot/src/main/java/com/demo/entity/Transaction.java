package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSACTION")
public class Transaction {
	
	@Column(name = "TRANSID")
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer transId;
	
	@Column(name = "ACCID", nullable = true, length = 10)
    private Integer accId;

    @Column(name = "TRANSTYPE", nullable = true, length = 20)
    private String transType;
    
    @Column(name = "BALANCE", nullable = true, length = 10)
    private Integer balance;
    
    

	public Transaction() {
		super();
	}

	public Transaction(Integer transId, Integer accId, String transType, Integer balance) {
		super();
		this.transId = transId;
		this.accId = accId;
		this.transType = transType;
		this.balance = balance;
	}

	public Integer getTransId() {
		return transId;
	}

	public void setTransId(Integer transId) {
		this.transId = transId;
	}

	public Integer getAccId() {
		return accId;
	}

	public void setAccId(Integer accId) {
		this.accId = accId;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public Integer getBalance() {
		return balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}
	
	
	

}
