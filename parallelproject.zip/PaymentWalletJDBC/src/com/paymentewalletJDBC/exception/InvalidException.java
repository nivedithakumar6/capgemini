package com.paymentewalletJDBC.exception;

public class InvalidException extends Exception {

	public InvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	public InvalidException() {
		super();
		// TODO Auto-generated constructor stub
	}                                        

}
