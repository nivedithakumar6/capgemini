package com.paymentewalletJDBC.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.paymentewalletJDBC.bean.Account;
import com.paymentewalletJDBC.bean.Transaction;

public class PaymentWalletJDBCDaoImpl implements IPaymentWalletJDBCDao {
	
	Connection con=null;
	PreparedStatement pst=null;
	
	 private void startDBConnection() throws SQLException
	 {
	 
	  String url ="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
	  String user ="trg219";
	  String pass="training219";
	  con = DriverManager.getConnection(url, user, pass);
	  System.out.println("Database Connected");
	 
	 }
	 
	 private void endDBConnection() throws SQLException
	 {
		 con.close();
	 }
	 
	 //Inserting Transaction DB
	 
	 private void insertTransaction(Transaction Trans) throws SQLException
	 {
		 
		 String qry1="INSERT INTO Transaction VALUES('"+Trans.getTransId()+"','"+Trans.getAccId()+"','"+Trans.getTypeTrans()
			+"','"+Trans.getBalance()+"')";
			
			Statement st2 = con.createStatement();
			int status1 =((java.sql.Statement) st2).executeUpdate(qry1);
			
				if(status1==1)
			{
				System.out.println("Transaction Data Inserted");
			}
			else
			{
				System.out.println("Transaction Data not Inserted");
			}
	 }
	 
	 //Updating Account DB
	 private void updateAccount(double balance,int accId) throws SQLException
	 {
		 
		 pst = con.prepareStatement("update account set balance =? where accId=?");
			pst.setDouble(1, balance);
			pst.setInt(2, accId);
			pst.executeUpdate();
	 }

	@Override
	public int createAccount(Account accId, Transaction Trans) throws SQLException {
		this.startDBConnection();

		String qry="INSERT INTO Account VALUES('"+accId.getAccId()+"','"+accId.getName()+"','"+accId.getMobile()
		+"','"+accId.getEmail()+"','"+accId.getPan()+"','"+accId.getType()+"','"+accId.getBalance()+"')";
//		System.out.println(qry);
		
		Statement st1 = con.createStatement();
		int status =((java.sql.Statement) st1).executeUpdate(qry);
		
			if(status==1)
		{
			System.out.println("Account Data Inserted");
		}
		else
		{
			System.out.println("Account Data not Inserted");
		}
		insertTransaction(Trans);
		this.endDBConnection();
		return accId.getAccId();
	}

	@Override
	public void showBalance(int accId) throws SQLException {
		double balance;
		this.startDBConnection();
		
		pst = con.prepareStatement("SELECT accId from Account WHERE accId =?");
		  pst.setInt(1,accId);
		  ResultSet rs0 = pst.executeQuery();
		  if(rs0.next()) {
		
		  pst = con.prepareStatement("select BALANCE from Account where ACCID = ?");
		  pst.setInt(1,accId);
		  ResultSet rs = pst.executeQuery();
		  if(rs.next())
		  {
		   balance = rs.getDouble(1);
		   System.out.println("Balance Amount: "+balance);
		  }
		  this.endDBConnection();
		  }
	else 
	{
		System.out.println("Account does not exists");
		this.endDBConnection();
	}
		  
	}

	@Override
	public void deposit(int accId1, double amt, Transaction Trans) throws SQLException {
		double balance=0;
		this.startDBConnection();
		pst = con.prepareStatement("SELECT accId from Account WHERE accId =?");
		  pst.setInt(1,accId1);
		  ResultSet rs0 = pst.executeQuery();
		  if(rs0.next()) {
			  
		  pst = con.prepareStatement("select BALANCE from Account where ACCID = ?");
		  pst.setInt(1,accId1);
		  ResultSet rs = pst.executeQuery();
		  if(rs.next())
		  {
		   balance = rs.getDouble(1);
		  }	
		  balance=balance+amt;
		  Trans.setBalance(balance);
		  insertTransaction(Trans);
		  updateAccount(balance,accId1);
				this.endDBConnection();
				System.out.println(balance+" amount is deposited  to "+accId1 );
	}
	else 
	{
		System.out.println("Account does not exists");
		this.endDBConnection();
	}
	
	}

	@Override
	public void withdraw(int accId2, double amt2, Transaction Trans) throws SQLException {
		
		double balance=0;
		this.startDBConnection();
		pst = con.prepareStatement("SELECT accId from Account WHERE accId =?");
		  pst.setInt(1,accId2);
		  ResultSet rs0 = pst.executeQuery();
		  if(rs0.next()) {
			  
		  pst = con.prepareStatement("select BALANCE from Account where ACCID = ?");
		  pst.setInt(1,accId2);
		  ResultSet rs = pst.executeQuery();
		  if(rs.next())
		  {
		   balance = rs.getDouble(1);
		  }	
		  balance=balance-amt2;
		  Trans.setBalance(balance);
		  insertTransaction(Trans);
		  updateAccount(balance,accId2);
		  this.endDBConnection();
		  System.out.println(balance+" amount is withdrawn  from "+accId2 );
		  }
		  else 
			{
				System.out.println("Account does not exists");
				this.endDBConnection();
			}
		
	}

	@Override
	public void fundTransfer(int accId3, int accId4, double amt3, Transaction Trans1, Transaction Trans2) throws SQLException {
		
		double balance1=0;
		double balance2=0;
		boolean test=false;
		this.startDBConnection();
		
		pst = con.prepareStatement("SELECT accId from Account WHERE accId =?");
		  pst.setInt(1,accId3);
		  ResultSet rs0 = pst.executeQuery();
		  if(rs0.next()) {
			  test=true;}
		  
		  else 
			{
			  test=false;
				System.out.println("Account does not exists");
				this.endDBConnection();
			}
		if(test==true) {
		//withdrawn 
		  pst = con.prepareStatement("select BALANCE from Account where ACCID = ?");
		  pst.setInt(1,accId3);
		  ResultSet rs = pst.executeQuery();
		  if(rs.next())
		  {
		   balance1 = rs.getDouble(1);
		  }	
		  balance1=balance1-amt3;
		  Trans1.setBalance(balance1);
		  insertTransaction(Trans1);
		  updateAccount(balance1,accId3);
				System.out.println(amt3+" amount is withdrawn  from "+accId3 );
		  
		  
		
				//deposited 
				  pst = con.prepareStatement("select BALANCE from Account where ACCID = ?");
				  pst.setInt(1,accId4);
				  ResultSet rs1 = pst.executeQuery();
				  if(rs1.next())
				  {
				   balance2 = rs1.getDouble(1);
				  }	
				  balance2=balance2+amt3;
				  Trans2.setBalance(balance1);
				  insertTransaction(Trans2);
				  updateAccount(balance2,accId4);
						System.out.println(amt3+" amount is withdrawn  from "+accId4 );
						this.endDBConnection();
		}
	}

	@Override
	public void printTransaciton(int accId5) throws SQLException {
		double balance;int transId;int accId;String typeTrans;
		this.startDBConnection();
		
		pst = con.prepareStatement("SELECT accId from Account WHERE accId =?");
		  pst.setInt(1,accId5);
		  ResultSet rs0 = pst.executeQuery();
		  if(rs0.next()) {
		
		  pst = con.prepareStatement("select * from transaction where ACCID = ?");
		  pst.setInt(1,accId5);
		  ResultSet rs = pst.executeQuery();
		  while(rs.next())
		  {
		   transId=rs.getInt(1);
		   accId=rs.getInt(2);
		   typeTrans=rs.getString(3);
		   balance = rs.getDouble(4);
		   System.out.println("Transaction ID: "+transId+", Account ID: "+accId+", Type of Transaction: "+typeTrans+", Balance Amount: "+balance);
		  }
		  }
		  else 
			{
				System.out.println("Account does not exists");
				this.endDBConnection();
			}
	}

}
