package com.paymentewalletJDBC.service;

import java.sql.SQLException;

import com.paymentewalletJDBC.bean.Account;
import com.paymentewalletJDBC.bean.Transaction;
import com.paymentewalletJDBC.exception.InvalidException;

public interface IPaymentWalletJDBCService {

	public int createAccount(Account accId, Transaction Trans) throws SQLException;
	public void showBalance(int accId) throws SQLException;
	public void deposit(int accId1, double amt, Transaction Trans) throws SQLException;
	public void withdraw(int accId2, double amt2,Transaction Trans) throws SQLException;
	public void fundTransfer(int accId3, int accId4, double amt3,Transaction Trans1, Transaction Trans2) throws SQLException;
	public void printTransaciton(int accId5) throws SQLException;
	public boolean validateName(String name) throws InvalidException;
	public boolean validateMobile(String mobile) throws InvalidException;
	public boolean validateEmail(String email) throws InvalidException;
	public boolean validatePan(String pan) throws InvalidException;
	public boolean validateType(String type) throws InvalidException;
	public boolean validateBalance(double openbal)throws InvalidException;
	
}
