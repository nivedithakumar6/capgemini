package com.paymentewalletJDBC.bean;

import java.time.LocalDate;
import java.util.Date;

public class Account {

	String name;
	String mobile;
	String email;
	String pan;
	String type;
	int accId;
	double balance;
	LocalDate date;


	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Account(String name, String mobile, String email, String pan, String type, double balance, LocalDate date) {
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.pan = pan;
		this.type = type;
		this.balance = balance;
		this.date=date;
	}
	
	

	public Account(String name, String mobile, String email, String pan, String type, int accId, double balance) {
		super();
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.pan = pan;
		this.type = type;
		this.accId = accId;
		this.balance = balance;
	}

	public Account(String name, String mobile, String email, String pan, String type, double balance) {
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.pan = pan;
		this.type = type;
		this.balance = balance;
	}
	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}


	public String getPan() {
		return pan;
	}


	public void setPan(String pan) {
		this.pan = pan;
	}
	
	
	
}
