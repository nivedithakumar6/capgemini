package com.cg.tms.exception;

public class InvalidPriorityException extends Exception
{

	public InvalidPriorityException(String string) {
		super(string);
	}

}
