package com.cg.WalletApplication.bean;

public class Wallet {
	int AccountId;
	String name;
	String mob;
	String pan;
	String gmail;
	String ano;
	String branch;
	int balance;
	String Acctype;
	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAccountId() {
		return AccountId;
	}
	public void setAccountId(int accountId) {
		AccountId = accountId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getGmail() {
		return gmail;
	}
	public void setGmail(String gmail) {
		this.gmail = gmail;
	}
	public String getAno() {
		return ano;
	}
	public void setAno(String ano) {
		this.ano = ano;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public Wallet(String name, String mob, String pan, String gmail,
			String ano, int balance, String branch,String acctype) {
		super();
		this.name = name;
		this.mob = mob;
		this.pan = pan;
		this.gmail = gmail;
		this.ano = ano;
		this.branch = branch;
		this.balance = balance;
		this.Acctype=Acctype;
	}
	public String getAcctype() {
		return Acctype;
	}
	public void setAcctype(String acctype) {
		Acctype = acctype;
	}
	
	
	
}
