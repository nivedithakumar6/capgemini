package com.cg.WalletApplication.bean;

public class Transcation {
	int transId;
	public int balance;
	public int getTransId() {
		return transId;
	}
	public Transcation() {
		super();
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public Transcation(int transId, int balance) {
		super();
		this.transId = transId;
		this.balance = balance;
	}
	
	
}
