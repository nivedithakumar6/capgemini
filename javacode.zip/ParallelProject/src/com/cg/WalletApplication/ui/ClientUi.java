package com.cg.WalletApplication.ui;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Scanner;

import com.cg.WalletApplication.bean.Transcation;
import com.cg.WalletApplication.bean.Wallet;
import com.cg.WalletApplication.service.IWalletService;
import com.cg.WalletApplication.service.WalletServiceImpl;
import com.cg.exception.InputMismatchException;

public class ClientUi {
	static IWalletService ser=null;
	 static Scanner scan =new Scanner(System.in); 
	public static void main(String[] args) {
		String res="no";
		do{
		System.out.println("Choose the service required :");
		System.out.println("1.CreateAccount\n2.Show Balance\n3.Deposit\n4.Withdraw\n5.Fund Transfer\n6.Print Transcations");
		switch(scan.nextInt()){
		case 1:
			int finalid=CreateAccount();
			System.out.println("Account is Created with accountId :"+finalid);
			System.out.println("Account opening date:"+LocalDate.now());
			System.out.println("Thanks for opening Account in our Bank");
			break;
		case 2:
			System.out.println("Enter the Id to see balance");
			int id=scan.nextInt();
			Wallet w =new Wallet();
			w=	ShowBalance(id);
			System.out.println("Your Balance :"+w.getBalance());
			break;
		case 3:
			System.out.println("Enter the Id to deposit balance");
			int id1=scan.nextInt();
			System.out.println("Enter the Amount :");
			int bal=scan.nextInt();
		//Wallet w1=new Wallet();
//		
		Wallet w1=Deposit(id1,bal);
			System.out.println("total balance :"+w1.getBalance());
			break;
		case 4:
			System.out.println("Enter the Id to deposit balance");
			int id2=scan.nextInt();
			System.out.println("Enter the Amount :");
			int am=scan.nextInt();
			//Wallet w2=new Wallet();
			Wallet w2=	Withdraw(id2,am);
			System.out.println("Please collect the money");
			System.out.println("Remaining balance :"+w2.getBalance());
			break;
		case 5:
			System.out.println("Enter the your Account Id:");
			int i=scan.nextInt();
			System.out.println("Enter the your Account Id:");
			int j=scan.nextInt();
			System.out.println("Enter the Amount :");
			int f=scan.nextInt();
			Wallet w3=FundTransfer(i,j,f);
			System.out.println("***Transcation Successful***");
			break;
		case 6:
			Collection<Transcation> c= printtransactions();
			System.out.println("Enter the Account Number to print Transactions ");
			int accnumber=scan.nextInt();
			System.out.println(c);
			for(Transcation trans:c){ 
			 System.out.println(trans.getTransId());
			 System.out.println(trans.getBalance());
			}
			break;
			default:
				break;
		}
		System.out.println("Do you want to continue:Y/N..");
		res=scan.next();
		}while(res.equalsIgnoreCase("y"));
	}

	private static Collection<Transcation> printtransactions() {
		// TODO Auto-generated method stub
		ser=new WalletServiceImpl();
		return ser.PrintTranscations();
	}

	public static int CreateAccount(){
		ser=new WalletServiceImpl();
		String name=null;
		String mob=null;
		String gmail=null;
		String pan=null;
		String ano=null;
		String Acctype=null;
		int balance=0;
		boolean res=false;
		do{
			try{
		System.out.println("Enter the Name of the Customer:");
		name=scan.next();
		res=ser.Validatename(name);
			}catch(InputMismatchException e){
				System.out.println(e);
			}
		}while(!res);
		do{
			res=false;
			try{
		System.out.println("Enter the mobile number:");
		mob=scan.next();
		res=ser.Validatemob(mob);
		}catch(InputMismatchException e){
			System.out.println(e);
		}
		}while(!res);
		do{
		res=false;
		try{
		System.out.println("Enter the gmail:");
		gmail=scan.next();
		res=ser.Validategmail(gmail);
		}catch(InputMismatchException e){
			System.out.println(e);
		}
		}while(!res);
		do{res=false;
		try{
		System.out.println("Enter the pan number:");
		pan=scan.next();
		res=ser.Validatepan(pan);
		}catch(InputMismatchException e){
			System.out.println(e);
		}
		}while(!res);
		do{
			res=false;
		try{
		System.out.println("Enter the aadhar number:");
		ano=scan.next();
		res=ser.Validateano(ano);
		}catch(InputMismatchException e){
			System.out.println(e);
		}
		}while(!res);
		do{
			res=false;
		try{
		System.out.println("Enter the opening balance:");
		balance=scan.nextInt();
		res=ser.Validatebalance(balance);
		}catch(InputMismatchException e){
			System.out.println(e);
		}
		}while(!res);
		do{
			res=false;	
		try{
		System.out.println("Enter the type of account");
		Acctype=scan.next();
		res=ser.ValidateAcctype(Acctype);
		}catch(InputMismatchException e){
			System.out.println(e);
		}
		}while(!res);
		System.out.println("Enter the branch:");
		String branch=scan.next();
		Wallet w=new Wallet(name,mob,gmail,pan,ano,balance,Acctype,branch);
		Transcation trans=new Transcation();
		int id=ser.CreateAccount(w,trans);
		return id;
		
	}
	public static Wallet ShowBalance(int id){
		ser=new WalletServiceImpl();
		return ser.Showbalance(id);
		
	}
	
	private static  Wallet Deposit(int id1, int bal) {
		// TODO Auto-generated method stub
		ser=new WalletServiceImpl();
		return ser.Deposit(id1,bal);
	}
	private static Wallet Withdraw(int id2, int am) {
		// TODO Auto-generated method stub
		ser=new WalletServiceImpl();
		return ser.Withdraw(id2,am);
	}
	private static Wallet FundTransfer(int i,int j, int f) {
		// TODO Auto-generated method stub
		ser=new WalletServiceImpl();
		return ser.FundTransfer(i,j,f);
	}

	
	
}
