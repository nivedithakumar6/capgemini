package com.cg.WalletApplication.service;

import java.util.Collection;
import java.util.regex.Pattern;

import com.cg.WalletApplication.bean.Transcation;
import com.cg.WalletApplication.bean.Wallet;
import com.cg.WalletApplication.dao.IWalletDao;
import com.cg.WalletApplication.dao.WalletDaoImpl;
import com.cg.exception.InputMismatchException;

public class WalletServiceImpl implements IWalletService{
	static IWalletDao dao=null;
	int CreateAccountId(){
		int id=(int)(Math.random()*100000);
		return id;
	}
	int TranscationId(){
		int tid=(int)(Math.random()*10000);
		return tid;
	}
	
	@Override
	public int CreateAccount(Wallet w, Transcation trans) {
		w.setAccountId(CreateAccountId());
		trans.setTransId(TranscationId());
		dao=new WalletDaoImpl();
		return dao.CreateAccount(w,trans);
		
	}
	@Override
	public Wallet Showbalance(int id) {
		 dao=new WalletDaoImpl();
		 return dao.Showbalance(id);
	}

	@Override
	public Wallet Deposit(int id1,int bal) {
		dao=new WalletDaoImpl();
		 return dao.Deposit(id1,bal);
	}

	@Override
	public Wallet Withdraw(int id2, int am) {
		// TODO Auto-generated method stub
		dao=new WalletDaoImpl();
		return dao.Withdraw(id2,am);
	}

	@Override
	public Wallet FundTransfer(int i,int j,int f) {
		// TODO Auto-generated method stub
		dao=new WalletDaoImpl();
		return dao.FundTransfer(i,j,f);
	}

	@Override
	public Collection<Transcation> PrintTranscations() {
		dao=new WalletDaoImpl();
		return dao.PrintTranscations();
		// TODO Auto-generated method stub
		
	}
	public boolean Validatename(String name) throws InputMismatchException{
		if	(!Pattern.compile("[A-Z][a-z]{2,}").matcher(name).find())
		{
				throw new InputMismatchException("not matching pattern");			
		}
		return true;
		
	}
	public boolean Validatemob(String mob) throws InputMismatchException{
		if	(!Pattern.compile("[6-9]\\d{9}").matcher(mob).find())
		{
				throw new InputMismatchException("not matching pattern");			
		}
		return true;
		
	}
	public boolean Validategmail(String gmail) throws InputMismatchException{
		if	(!Pattern.compile("[A-Z a-z 0-9.]{1,}@gmail.com").matcher(gmail).find())
		{
				throw new InputMismatchException("not matching pattern");			
		}
		return true;
		
	}
	public boolean Validatepan(String pan) throws InputMismatchException{
		if	(!Pattern.compile("[A-Z]{4}\\d{4}[A-z][A-Z]").matcher(pan).find())
		{
				throw new InputMismatchException("not matching pattern");			
		}
		return true;
		
	}
	public boolean Validateano(String ano) throws InputMismatchException{
		if	(!Pattern.compile("\\d{12}").matcher(ano).find())
		{
				throw new InputMismatchException("not matching pattern");			
		}
		return true;
		
	}public boolean ValidateAcctype(String Acctype) throws InputMismatchException{
		
		if (Acctype.equalsIgnoreCase("saving")||Acctype.equalsIgnoreCase("current"))
		{
			return true;
		}	
		else
			throw new InputMismatchException("not matching pattern");
	}
	public boolean Validatebalance(int balance) throws InputMismatchException{
		
		if (balance>500)
		{
			return true;
		}	
		else
			throw new InputMismatchException("not matching pattern");
	}

	


	}
	
	


