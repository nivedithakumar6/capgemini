package com.cg.WalletApplication.service;

import java.util.Collection;

import com.cg.WalletApplication.bean.Transcation;
import com.cg.WalletApplication.bean.Wallet;
import com.cg.exception.InputMismatchException;

public interface IWalletService {
	  public abstract int CreateAccount(Wallet w,Transcation trans);
	  public abstract Wallet Showbalance(int id);
	  public abstract Wallet Deposit(int id1,int bal);
	  public abstract Wallet Withdraw(int id2, int am);
	  public abstract Wallet FundTransfer(int i,int j,int f);
	  public abstract Collection<Transcation> PrintTranscations();
	  public boolean Validatename(String name) throws InputMismatchException;
	  public boolean Validatemob(String mob) throws InputMismatchException;
	  public boolean Validategmail(String gmail) throws InputMismatchException;
	  public boolean Validatepan(String pan) throws InputMismatchException;
	  public boolean Validateano(String ano) throws InputMismatchException;
	  public boolean Validatebalance(int balance) throws InputMismatchException;
	  public boolean ValidateAcctype(String Acctype) throws InputMismatchException;  
}
