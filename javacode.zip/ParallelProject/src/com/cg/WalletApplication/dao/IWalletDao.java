package com.cg.WalletApplication.dao;

import java.util.Collection;

import com.cg.WalletApplication.bean.Transcation;
import com.cg.WalletApplication.bean.Wallet;

public interface IWalletDao {
	  public abstract int CreateAccount(Wallet w,Transcation trans);
	  public abstract Wallet Showbalance(int id);
	  public abstract Wallet Deposit(int id1,int bal);
	  public abstract Wallet Withdraw(int id2,int am);
	  public abstract Wallet FundTransfer(int i,int j,int f);
	  public abstract Collection<Transcation> PrintTranscations();
	
	
	

}
