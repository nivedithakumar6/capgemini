package com.cg.WalletApplication.dao;

import java.util.Collection;
import java.util.HashMap;

import com.cg.WalletApplication.bean.Transcation;
import com.cg.WalletApplication.bean.Wallet;

public class WalletDaoImpl implements IWalletDao{

	static HashMap<Integer,Wallet> data=new HashMap<Integer,Wallet>();
	static HashMap<Integer,Transcation> data1=new HashMap<Integer,Transcation>();
	
	
	@Override
	public int CreateAccount(Wallet w,Transcation trans) {
	data.put(w.getAccountId(), w);
	data1.put(trans.getTransId(), trans);
	trans.setBalance(w.getBalance());
		return w.getAccountId();
		
	}

	@Override
	public Wallet Showbalance(int id) {
		
		return data.get(id);
		
		
	}

	@Override
	public Wallet Deposit(int id1,int bal) {
		//Wallet w=new Wallet();
		//System.out.println(w.getAccountId()+" "+w.getBalance());
		Wallet w=data.get(id1);
		System.out.println(w.getAccountId()+" "+w.getBalance());
		int bal1=w.getBalance();
		int res1=bal+bal1;
		w.setBalance(res1);
		return data.get(id1);
		
		
		
	}

	@Override
	public Wallet Withdraw(int id2,int am) {
		//Wallet w=new Wallet();
		Wallet w=data.get(id2);
		int res=w.getBalance();
		int t=res-am;
		w.setBalance(t);
		return data.get(id2);
		// TODO Auto-generated method stub
		
	}

	@Override
	public Wallet FundTransfer(int i,int j,int f) {
		//Wallet w=new Wallet();
		Wallet	w=data.get(i);
		int r=w.getBalance();
		int t1=r-f;
		w.setBalance(t1);
	//	Wallet w1=new Wallet();
		Wallet	w1=data.get(j);
		int r1=w1.getBalance();
		int t2=r1+f;
		w1.setBalance(t2);
		return null;
	}

	@Override
	public Collection<Transcation> PrintTranscations() {
		Collection<Transcation> c=data1.values();
		
		return c;
	}

}
