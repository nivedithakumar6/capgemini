package com.cg.exception;

public class InputMismatchException extends Exception{
 
	InputMismatchException(){
		super();
	}

	public InputMismatchException(String message) {
		super(message);
		
	}
	
}
