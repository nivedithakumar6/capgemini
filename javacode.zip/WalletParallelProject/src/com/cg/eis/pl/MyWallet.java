package com.cg.eis.pl;
import com.cg.eis.service.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import com.cg.eis.bean.*;

public class MyWallet {
 public static void main(String[] args) throws IOException {
 // TODO Auto-generated method stub
 WalletService service = new WalletServiceImpl();
 BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
 System.out.println("Enter no of accounts");
 int a_no=Integer.parseInt(br.readLine());
 for(int i=1;i<=a_no;i++)
 {
 System.out.println("Enter Details of Account Holder : "+i);
 //System.out.println("Enter Account No : ");
 int accno = (int)((Math.random())*10000);
 //System.out.println(accno);
 System.out.println("Enter Account Holder Name : ");
 String cusName = br.readLine();

 System.out.println("Enter Mobile Number : ");
 boolean b=false;
 long mob = 0;
 do {
  String mobile = br.readLine();
  if(service.validateMobile(mobile))
  {
  mob= Long.parseLong(mobile);
  b=true;
  }

  else
  System.out.println("Re-Enter Correct Mobile Number : ");
  }while(b!=true);
 System.out.println("Enter Account Balance : ");
 Double bal = Double.parseDouble(br.readLine());
 Account a1 = new Account(accno,cusName,mob,bal);
 boolean added = service.createAccount(a1);
 System.out.println("Account added : "+added);
 }

 System.out.println("1.Diplay All Accounts\n2.Update an Account\t3.Delete an Account"+
    "\n4.Transfer Money\t5.Add Money\t6.Get Account using mobile");
 int ch = Integer.parseInt(br.readLine());
 int i=0;
 do {
  i++;
  switch(ch)
  {
  case 1 :
   service.getAllAccount();
   //System.out.println(allAc);
   break;
   
  case 2 :
   System.out.println("Update Function is not Available.");
   break;
   
  case 3 :
   System.out.println("Enter Mobile number to delete the Account :");
   long mob2 = Long.parseLong(br.readLine());
   boolean res = service.deleteAccount(mob2);
   System.out.println("Delete Successful "+res);
   break;

  case 4 :
   System.out.println("Enter Money to Transfer : ");
   double amount = Double.parseDouble(br.readLine());
   System.out.println("Enter Sender Mobile Number : ");
   long mono1=Long.parseLong(br.readLine());
   System.out.println("Enter Receiver Mobile NUmber : ");
   long mono2=Long.parseLong(br.readLine());
   Account a1=service.getAccountByMobile(mono1);
   Account a2=service.getAccountByMobile(mono2);
   boolean trans = service.transferMoney(amount, a1, a2);
   System.out.println(trans+" Transfer");
   break;

  case 5 :
   System.out.println("Enter Money to add");
   double amt = Double.parseDouble(br.readLine());
   //String m1=br.readLine();
   System.out.println("Enter Mobile number to add Money");
   long mono=Long.parseLong(br.readLine());
   Account ob1=service.getAccountByMobile(mono);
   boolean res1 = service.addMoney(amt, ob1);
   System.out.println(res1);
   break;

  case 6 :
   System.out.println("Enter Mobile Number to retrieve Account");
   long mob1 = Long.parseLong(br.readLine());
   System.out.println(mob1);
   Account myAc = service.getAccountByMobile(mob1);
   System.out.println(myAc);
   break;

  default :
   System.out.println("Choose Valid Option : ");
   break;
  }

  System.out.println("1.Diplay All Accounts\t2.Update an Account\n3.Delete an Account\t4.Transfer Money\n5.Add Money\t6.Get Account using mobile\n7.Exit");
  ch = Integer.parseInt(br.readLine());
  if(ch==7)
  System.out.println("Exited");
 }while(ch!=7);
 }
}

