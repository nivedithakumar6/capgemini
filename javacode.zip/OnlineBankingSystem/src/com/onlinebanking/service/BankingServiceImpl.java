package com.onlinebanking.service;

import java.util.regex.*;

import com.onlinebanking.bean.Account;
import com.onlinebanking.dao.BankingDaoImpl;
import com.onlinebanking.dao.IBankingdao;

public class BankingServiceImpl  implements IBankingService{
	IBankingdao idao=null;
	static Matcher m=null;
	static Pattern p=null;
	private int generateAccountId(){
		int n=(int)(Math.random()*10000);
		return n;
	}
	@Override
	public int createAccount(Account acc) {
		acc.setAccountId(generateAccountId());//modicf
		//pass to dao
		idao=new BankingDaoImpl();
		return idao.createAccount(acc);
	}

	@Override
	public void updateAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withDraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkAllTransactions() {
		// TODO Auto-generated method stub
		
	}
	
	public boolean validateName(String name)
	{
		p=Pattern.compile("^[A-Z]\\w{3}");
		m=p.matcher(name);
		
		if(m.find())
		{
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean validateMobile(String mob)
	{
		p=Pattern.compile("^[6-9]{1}\\d{9}$");
		m=p.matcher(mob);
		
		if(m.find())
		{
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean validateEmail(String email)
	{
		p=Pattern.compile("^[A-Z a-z 0-9.]{1,}@gmail.com$");
		m=p.matcher(email);
		
		if(m.find())
		{
			
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean validatePan(String pan)
	{
		p=Pattern.compile("^[A-Z a-z 0-9]{10}$");
		m=p.matcher(pan);
		
		if(m.find())
		{
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean validateAccType(String accType)
	{
		
		if((accType.equalsIgnoreCase("Saving")) || (accType.equalsIgnoreCase("current")))
		{
			
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean validateBalance(int balance)
	{
		
		if(balance>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}
