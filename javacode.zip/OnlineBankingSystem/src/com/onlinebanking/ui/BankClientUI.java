package com.onlinebanking.ui;
import java.util.Scanner;

import com.onlinebanking.bean.Account;
import com.onlinebanking.service.BankingServiceImpl;
import com.onlinebanking.service.IBankingService;

public class BankClientUI {

	static Scanner scan = new Scanner(System.in);
	static IBankingService iserv=null;
	static String name=null;
	public static void main(String[] args) {

		System.out.println("enter any option b/1 to 5");
		System.out
				.println(" 1. Create Account \n 2. Update Account\n 3.delete Account");
		System.out.println("4. check All Transacions \n 5. transfer ");
		switch (scan.nextInt()) {

		case 1:
			int finalAccId=createAccount();
			System.out.println("account info is stored");
			System.out.println("ur account id is "+finalAccId);
			break;
		case 2:

			break;

		case 3:

			break;
		case 4:

			break;
		case 5:

			break;
		default:
			break;

		}
	}

	private static int createAccount() {
		iserv=new BankingServiceImpl();//object
		
		//validation of name
		
		System.out.println("enter the account holder name");
		String name=scan.next();
		do
		{
			iserv.validateName(name);
			if((iserv.validateName(name))==false)
			{
				System.out.println("enter a valid name with caps in starting");
				name=scan.next();
			}
			else
			{
				break;
			}
		}
		while((iserv.validateName(name))==false);

		//validation of mobile no
		
		
		System.out.println("enter the Mobile number");
		String mob=scan.next();
		
		do
		{
			iserv.validateMobile(mob);
			if((iserv.validateMobile(mob))==false)
			{
				System.out.println("enter a valid mobile number");
				mob=scan.next();
			}
			else
			{
				break;
			}
		}
		while((iserv.validateMobile(mob))==false);
		
		//validation of email
		
		System.out.println("enter the email");
		String email=scan.next();
				
				do
				{
					iserv.validateEmail(email);
					if((iserv.validateEmail(email))==false)
					{
						System.out.println("enter a valid email number");
						email=scan.next();
					}
					else
					{
						break;
					}
				}
				while((iserv.validateEmail(email))==false);
				
		//validation of Pan Number
		
		System.out.println("enter the Pan Number");
		String pan=scan.next();
		
		do
		{
			iserv.validatePan(pan);
			if((iserv.validatePan(pan))==false)
			{
				System.out.println("enter a valid pan number");
				pan=scan.next();
			}
			else
			{
				break;
			}
		}
		while((iserv.validatePan(pan))==false);
		
		//validation of account type
		
		System.out.println("enter the account type");
		String accType=scan.next();
		
		do
		{
			iserv.validateAccType(accType);
			if((iserv.validateAccType(accType))==false)
			{
				System.out.println("enter a valid account type");
				accType=scan.next();
			}
			else
			{
				break;
			}
		}
		while((iserv.validateAccType(accType))==false);
		

		//validation of balance
		
		
		System.out.println("enter the account opening balance");
		int balance=scan.nextInt();
		
		do
		{
			iserv.validateBalance(balance);
			if((iserv.validateBalance(balance))==false)
			{
				System.out.println("enter a valid balance");
				balance=scan.nextInt();
			}
			else
			{
				break;
			}
		}
		while((iserv.validateBalance(balance))==false);
		
		
		System.out.println("enter the branch");
		String branch=scan.next();
		
		//store it in bean
		Account account=new Account(name,mob,email,pan,accType,balance,branch);
		
		//validated
		
		
		//validation is successfull
		
		int aid=iserv.createAccount(account);
		
		return aid;
	}
	

}
