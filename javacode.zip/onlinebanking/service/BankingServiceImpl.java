package com.onlinebanking.service;

import com.onlinebanking.bean.Account;
import com.onlinebanking.dao.BankingDaoImpl;
import com.onlinebanking.dao.IBankingdao;

public class BankingServiceImpl  implements IBankingService{
	IBankingdao idao=null;
	private int generateAccountId(){
		return (int)Math.random()*10000;
	}
	@Override
	public int createAccount(Account acc) {
		acc.setAccountId(generateAccountId());//modicf
		//pass to dao
		idao=new BankingDaoImpl();
		return idao.createAccount(acc);
	}

	@Override
	public void updateAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withDraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkAllTransactions() {
		// TODO Auto-generated method stub
		
	}

	
}
