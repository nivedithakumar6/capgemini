package com.onlinebanking.bean;

public class Account {
	int accountId;
	String accountHolderName;
	String mob; 
	String email;
	String pan;
	String accountType;
	int openingBalance;
	String branch;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public int getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(int openingBalance) {
		this.openingBalance = openingBalance;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public Account(String accountHolderName, String mob, String email,
			String pan, String accountType, int openingBalance, String branch) {
		this.accountHolderName = accountHolderName;
		this.mob = mob;
		this.email = email;
		this.pan = pan;
		this.accountType = accountType;
		this.openingBalance = openingBalance;
		this.branch = branch;
	}
	

}
