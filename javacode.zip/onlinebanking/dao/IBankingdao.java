package com.onlinebanking.dao;

import com.onlinebanking.bean.Account;

public interface IBankingdao {
	public int createAccount(Account acc);
	public void	updateAccount();
	public void deleteAccount();
	public void withDraw();
	public void checkAllTransactions();
}
