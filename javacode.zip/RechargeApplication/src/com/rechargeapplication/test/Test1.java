package com.rechargeapplication.test;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.dao.IRechargedao;
import com.rechargeapplication.dao.Rechargedao;

	public class Test1 {

		IRechargedao rdao1=null;
		
		@BeforeAll
		public void Init()
		{
			rdao1= new Rechargedao() ;
		}
		
		@AfterAll
		public void Termi()
		{
			rdao1=null;
		}
		@Test
		public void testRechargePlan()
		{
			Recharge rech=new Recharge("Niveditha","9123456789","Welcome","Prepaid");
			rech.setTid(10001);
			int Tid=rdao1.rechargePlan(rech);
			Assertions.assertEquals(Tid, 10001);
			
		}
		
		@Test
		public void testViewAllTransaction()
		{
			Recharge rech=new Recharge();
			Assertions.assertNotNull(rdao1);
			
		}
		
		@Test
		public void testViewByTid()
		{
			Recharge rech=new Recharge();
			rech.setTid(10001);
			rdao1.viewByTid(rech.getTid());
			Assertions.assertNotNull(rdao1);
			
		}
		
		@Test
		public void testUpdateDesc()
		{
			Recharge rech=new Recharge("Niveditha","9123456789","Welcome","Prepaid");
			rech.setTid(10001);
			rech.setDesc("Hello");
			Assertions.assertEquals(rech.getDesc(),"hello");
		}
		
		@Test
		public void testDelete() {
			Recharge rech=new Recharge();
			rech.setTid(10001);
			rdao1.viewByTid(rech.getTid());
			Assertions.assertNotNull(rdao1);
		}
}
