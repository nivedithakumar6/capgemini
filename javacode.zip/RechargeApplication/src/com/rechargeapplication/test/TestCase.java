package com.rechargeapplication.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.dao.IRechargedao;
import com.rechargeapplication.dao.Rechargedao;

public class TestCase {

	IRechargedao rdao1=null;
	
	@Before
	public void Init()
	{
		rdao1= new Rechargedao() ;
	}
	
	@After
	public void Termi()
	{
		rdao1=null;
	}
	@Test
	public void testRechargePlan()
	{
		Recharge rech=new Recharge("Niveditha","9123456789","Welcome","Prepaid");
		rech.setTid(10001);
		int Tid=rdao1.rechargePlan(rech);
		Assert.assertEquals(Tid, 10001);
		
	}
	
	@Test
	public void testViewAllTransaction()
	{
		
		Recharge rech=new Recharge();
		rdao1.viewAllTrans();
		Assert.assertNotNull(rdao1);
		
	}
	
	@Test
	public void testViewByTid()
	{
		Recharge rech=new Recharge();
		rech.setTid(10001);
		rdao1.viewByTid(rech.getTid());
		Assert.assertNotNull(rdao1);
		
	}
	
	@Test
	public void testUpdateDesc()
	{
		Recharge rech=new Recharge("Niveditha","9123456789","Welcome","Prepaid");
		rech.setTid(10001);
		rech.setDesc("Hello");
		Assert.assertEquals(rech.getDesc(),"Hello");
	}
	@Test
	public void testDelete() {
		Recharge rech=new Recharge();
		rech.setTid(10001);
		rdao1.viewByTid(rech.getTid());
		Assert.assertNotNull(rdao1);
	}
}
