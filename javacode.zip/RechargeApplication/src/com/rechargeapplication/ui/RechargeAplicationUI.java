package com.rechargeapplication.ui;

import java.util.Scanner;

import com.rechargeapplication.service.IRechargeService;
import com.rechargeapplication.service.RechargeService;
import com.rechargeapplication.bean.*;

public class RechargeAplicationUI {
	static Scanner scan=new Scanner(System.in);
	static String name;
	static String mob;
	static String desc;
	static String rtype;
	static boolean res=false;
	static IRechargeService iser=null;
	static String h;

	public static void main(String[] args) {
		
		String choice=null;
		 int k=3000,l=0;
		do
		{
			
			System.out.println("Select the your choice from 1-5 where ");
			System.out.println("1. Recharge\n2. View all transaction\n3. View by Recherge Id\n"
								+ "4. Update Description\n5. Delete By id");
			int n=scan.nextInt();
			switch (n) {
				case 1:
					System.out.println("Select the plan for recharging from 1 and 2");
					System.out.println("1. RS.99\n2. RS.199");
					int m=scan.nextInt();
					
					switch (m) {
					case 1:
						
						int finalTid=rechargePlan();
						System.out.println("Recharge is done for Rs.99");
						System.out.println("Your Transaction id: "+finalTid);
						l=99;
						k=k-l;
						System.out.println("Balance: "+k);
						break;
					case 2:
						
						int finalTid1=rechargePlan();
						System.out.println("Recharge is done for Rs.199");
						System.out.println("Your Transaction id: "+finalTid1);
						l=199;
						k=k-l;
						System.out.println("Balance: "+k);
						break;

					default:
						System.out.println("Invalid choice");
						break;
					}
					
								
					break;
				case 2:viewAllTrans();
			
					break;	
				case 3:
					System.out.println("Enter the Transaction Id to be viewed:");
					int Tid=scan.nextInt();
					viewByTid(Tid);
			
					break;
				case 4:
					System.out.println("Enter the id to to which description to be changed:");
					int Tid2=scan.nextInt();
					System.out.println("Enter the updated description");
					String desc1=scan.next();
					updateDesc(Tid2,desc1);
			
					break;
				case 5:
					System.out.println("Enter the Transaction Id to be deleted:");
					int Tid1=scan.nextInt();
					deleteByTid(Tid1);
			
					break;
				default:
					System.out.println("choose your proper choice from 1-5");
					n=scan.nextInt();
					break;
			}
					System.out.println("do you want to continue y/n");
					h=scan.next();
		}
		while(h.equalsIgnoreCase("y"));
		
	}
	
	
private static void updateDesc(int Tid2, String desc1) {
		
	iser.updateDesc(Tid2,desc1);
	
	}


private static void deleteByTid(int Tid1) {
	iser=new RechargeService();
	iser.deleteByTid(Tid1);
		
	}


private static void viewByTid(int Tid) {
		
	iser=new RechargeService();
	iser.viewByTid(Tid);
		
	}


private static void viewAllTrans() {
	
		iser=new RechargeService();
		iser.viewAllTrans();
		
	}


//Recharge	
	
	
	private static int rechargePlan()
	{
		iser=new RechargeService();
		int m=0;
		//validation
		do
		{
			try
			{
				System.out.println("Enter  name");
				name=scan.next();
				res=iser.validateName(name);
			}
			catch(ArithmeticException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter  Mobile Number");
				mob=scan.next();
				res=iser.validateMobile(mob);
			}
			catch(ArithmeticException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter description");
				desc=scan.next();
				res=iser.validateDesc(desc);
			}
			catch(ArithmeticException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter recharge type: Postpaid Or Prepaid");
				rtype=scan.next();
				res=iser.validateRechargeType(rtype);
			}
			catch(ArithmeticException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		
		
		Recharge robj=new Recharge(name,mob, desc,rtype);
		iser=new RechargeService();
		int tid=iser.rechargePlan(robj);
		return tid;
		
	}
	

}
