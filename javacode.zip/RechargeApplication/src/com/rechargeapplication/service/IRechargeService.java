package com.rechargeapplication.service;

import com.rechargeapplication.bean.Recharge;

public interface IRechargeService {

	public int rechargePlan(Recharge Tid);
	public void viewAllTrans();
	public void viewByTid(int tid);
	public void updateDesc(int tid2, String desc1);
	public void deleteByTid(int Tid1);
	
	public boolean validateName(String name);
	public boolean validateMobile(String mob);
	public boolean validateDesc(String desc);
	public boolean validateRechargeType(String rtype);
	
	

}
