package com.rechargeapplication.service;

//import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;


import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.dao.Rechargedao;

public class RechargeService implements IRechargeService {
	
	static boolean res=false;
	static Rechargedao rdao=null;
	
	private int generateTransactionId(){
		int n=(int)(Math.random()*10000);
		return n;
	}
	private Date generateDate(){
		//SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    Date date = new Date();
		return date; 
	}
	
	@Override
	public int rechargePlan(Recharge Tid) {
		Tid.setTid(generateTransactionId());
		Tid.setDate(generateDate());
		
		rdao=new Rechargedao();
		return rdao.rechargePlan(Tid);
		
	}

	@Override
	public void viewAllTrans() {
		rdao=new Rechargedao();
		rdao.viewAllTrans();
		
	}

	@Override
	public void viewByTid(int Tid) {
		
		rdao=new Rechargedao();
		rdao.viewByTid(Tid);
		
	}

	@Override
	public void updateDesc(int Tid2,String desc1) {
		
		rdao=new Rechargedao();
		rdao.updateDesc(Tid2, desc1);
		
	}

	@Override
	public void deleteByTid(int Tid1) {
		rdao=new Rechargedao();
		rdao.deleteByTid(Tid1);
		
	}
	
	//validate name
	public boolean validateName(String name)
	{
		if(name==null ||name.equals(null))
		{
			throw new ArithmeticException("object is null");
		}
		if(!Pattern.compile("^[A-Z][a-z]{3,}").matcher(name).find())
		{
			throw new ArithmeticException("Enter the proper format");
		}
		
		return true;
		
	}
	
	//validate mobile number
	public boolean validateMobile(String mob)
	{
		if(mob==null ||mob.equals(null))
		{
			throw new ArithmeticException("object is null");
		}
		if(!Pattern.compile("^[6-9]{1}[0-9]{9}").matcher(mob).find())
		{
			throw new ArithmeticException("Enter the proper format");
		}
		
		return true;
		
	}
	
	//validate Description
	public boolean validateDesc(String desc)
	{
		if(desc==null ||desc.equals(null))
		{
			throw new ArithmeticException("object is null");
		}
		if(!Pattern.compile("^[A-z a-z 0-9]{2,}").matcher(desc).find())
		{
			throw new ArithmeticException("Enter the proper format");
		}
		return true;
	}
	
	//validate rechargetype
	public boolean validateRechargeType(String rtype)
	{
		if(rtype==null ||rtype.equals(null))
		{
			throw new ArithmeticException("object is null");
		}
		if(!(rtype.equalsIgnoreCase("Postpaid") || rtype.equalsIgnoreCase("Prepaid")))
		{
			throw new ArithmeticException("Enter the proper format");
		}
		return true;
	}

}
