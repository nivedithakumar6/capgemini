package com.rechargeapplication.dao;

import com.rechargeapplication.bean.Recharge;

public interface IRechargedao {
	
	public int rechargePlan(Recharge Tid);
	public void viewAllTrans();
	public void viewByTid(int Tid);
	public void updateDesc(int Tid2,String desc1);
	public void deleteByTid(int Tid1);
	
	public boolean validateName(String name);
	public boolean validateMobile(String mob);
	public boolean validateDesc(String desc);
	public boolean validateRechargeType(String rtype);

}
