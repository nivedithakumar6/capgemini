package com.rechargeapplication.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import com.rechargeapplication.bean.Recharge;


public class Rechargedao implements IRechargedao {


	static Map<Integer, Recharge> TransactionList=new HashMap<>();
	
	
	
	@Override
	public int rechargePlan(Recharge Tid) {
		
		TransactionList.put(Tid.getTid(), Tid);
		//System.out.println(TransactionList);
		return Tid.getTid();
		
	}

	@Override
	public void viewAllTrans() {
		
		Collection<Recharge> list=TransactionList.values();
		for(Recharge e1:list)
		{
			System.out.println("Name: "+e1.getName());
			System.out.println("Mobile Number: "+e1.getMob());
			System.out.println("Description: "+e1.getDesc());
			System.out.println("Recharge Type: "+e1.getRType());
			System.out.println("transaction Id: "+e1.getTid());
			System.out.println("Date Of recharge: "+e1.getDate());
		}
		
	}

	@Override
	public void viewByTid(int Tid) {
		
		Collection<Recharge> list=TransactionList.values();
		Recharge r=TransactionList.get(Tid);
		System.out.println("Name: "+r.getName());
		System.out.println("Mobile Number: "+r.getMob());
		System.out.println("Description: "+r.getDesc());
		System.out.println("Recharge Type: "+r.getRType());
		System.out.println("transaction Id: "+r.getTid());
		System.out.println("Date Of recharge: "+r.getDate());
		
		
	}

	@Override
	public void updateDesc(int Tid2,String desc1) {
		Collection<Recharge> c1=TransactionList.values();
		Recharge r=TransactionList.get(Tid2);
		r.setDesc(desc1);
		System.out.println("Description updated");
		
	}

	@Override
	public void deleteByTid(int Tid1) {
		
		Collection<Recharge> c1=TransactionList.values();
		TransactionList.remove(Tid1);
		System.out.println("Transaction Deleted");
		
	}

	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean validateMobile(String mob) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateDesc(String desc) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateRechargeType(String rtype) {
		// TODO Auto-generated method stub
		return false;
	}

}
