package com.rechargeapplication.bean;

import java.util.Date;

public class Recharge {

	String name=null;
	String mob;
	String desc;
	String rType;
	Date date;
	int Tid;
	
	
	public Recharge() {
		
	}

	public Recharge(String name, String mob, String desc, String rType) {
		super();
		this.name = name;
		this.mob = mob;
		this.desc = desc;
		this.rType = rType;
	}

	public Recharge(String name, String mob, String desc, String rType, Date date, int amount, int Tid) {
		super();
		this.name = name;
		this.mob = mob;
		this.desc = desc;
		this.rType = rType;
		this.date = date;
		this.Tid = Tid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getRType() {
		return rType;
	}

	public void setType(String rType) {
		this.rType = rType;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}


	public int getTid() {
		return Tid;
	}

	public void setTid(int Tid) {
		this.Tid = Tid;
	}

//	@Override
//	public String toString() {
//		return "Recharge [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
//				+ "]";
//	}
	
	
	
	
	
	
	
	
}
