package com.paymentwallet.dao;

import com.paymentwallet.bean.Payment;
import com.paymentwallet.bean.Transaction;

public interface IPaymentWalletDao {
	
	
	public void showBalance(int accId);
	public void deposit(int accId1, double amt,Transaction Trans);
	public void withdraw(int accId2, double amt2);
	public int createAccount(Payment accId, Transaction Trans);
	public void fundTransfer(int accId3, int accId4, double amt3);
	public void printTransaciton();
	
}
