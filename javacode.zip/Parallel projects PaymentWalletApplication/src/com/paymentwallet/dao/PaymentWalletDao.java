package com.paymentwallet.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.paymentwallet.bean.Payment;
import com.paymentwallet.bean.Transaction;

public class PaymentWalletDao implements IPaymentWalletDao{
	
	static Map<Integer, Payment> AccountList=new HashMap<>();
	static Map<Integer, Transaction> TransactionList=new HashMap<>(); 

	@Override
	public int createAccount(Payment accId,Transaction Trans) {
		
		AccountList.put(accId.getAccId(), accId);
		TransactionList.put(accId.getAccId(), Trans);
		return accId.getAccId();
	}

	@Override
	public void showBalance(int accId) {
		Collection<Payment> t=AccountList.values();
		Payment r=AccountList.get(accId);
		System.out.println("Available balance: "+r.getOpenbal());
	}

	@Override
	public void deposit(int accId1, double amt, Transaction Trans) {
		Payment r1=AccountList.get(accId1);
		double d=r1.getOpenbal();
		d=d+amt;
		r1.setOpenbal(d);
		Trans.setOpenbal(d);
//		Trans.setDeposit(amt);

		TransactionList.put(accId1, Trans);
		System.out.println("You have deposited "+amt+" on"+r1.getDate());
		System.out.println("Available Balance: "+Trans.getOpenbal());
//		Transaction a=TransactionList.get(accId1);
//		System.out.println("the deposaited amount is:"+a.getDeposit());
		 
	}



	@Override
	public void withdraw(int accId2, double amt2) {
		Payment r1=AccountList.get(accId2);
		double d=r1.getOpenbal();
		d=d-amt2;
		r1.setOpenbal(d);
		Transaction r2=new Transaction(accId2);
		r2.setOpenbal(d);
		r2.setDate(r1.getDate());
		r2.setTypeTrans("Withdrawn");
		System.out.println("You have Withdrawn "+amt2+" on"+r1.getDate());
		System.out.println("Available Balance: "+r2.getOpenbal());
		
	}

	@Override
	public void fundTransfer(int accId3, int accId4, double amt3) {
		Payment r1=AccountList.get(accId3);
		System.out.println(r1.getOpenbal());
		double d1=r1.getOpenbal();
		Payment r2=AccountList.get(accId4);
		double d2=r2.getOpenbal();
		Transaction r3=new Transaction(accId3);
		r3.setTypeTrans("withdrawn");
		d1=d1-amt3;
		r1.setOpenbal(d1);
		r3.setOpenbal(d1);
		System.out.println("Balance in "+accId3 +" is "+r3.getOpenbal());
		Transaction r4=new Transaction(accId4);
		d2=d2+amt3;
		r2.setOpenbal(d2);
		r4.setOpenbal(d2);
		System.out.println("Balance in "+accId4 +" is "+r4.getOpenbal());
	}

	public void printTransaciton() {
		Collection<Transaction> tlist=TransactionList.values();
		for(Transaction entry:tlist ) {

            System.out.println("Account No: "+entry.getAccId()+" Balance: "+entry.getOpenbal()+" Type Of Transaction: "+entry.getTypeTrans()+" Date: "+entry.getDate());
//            Transaction a=TransactionList.get(accId);
//            System.out.println("depoisted :"+a.getDeposit());
		}
		//System.out.println(p.getAccId()+" "+p.getOpenbal()+" "+p.getTypeTrans()+" "+p.getDate());
		
	}
//	public int printTransaction() {
//		
//		System.out.println("depoisted :");
//		return 0;
//		
//	}
//
//	@Override
//	public void printTransaciton() {
//		// TODO Auto-generated method stub
//		
//	}

	
	
	

}
