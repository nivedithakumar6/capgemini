package com.paymentwallet.bean;

import java.time.LocalDate;

public class Transaction {

	int accId;
	double openbal;
	String typeTrans;
//	double Deposit;
//	String Withdraw;
//	String FundTransfer;
	LocalDate date;
	
	public Transaction(double openbal) {
		this.openbal = openbal;
	}

	public Transaction(int accId, double openbal, String typeTrans, LocalDate date) {
		this.accId = accId;
		this.openbal = openbal;
		this.typeTrans = typeTrans;
		this.date = date;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Transaction() {
		
	}

	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public double getOpenbal() {
		return openbal;
	}
	public void setOpenbal(double openbal) {
		this.openbal = openbal;
	}
	public String getTypeTrans() {
		return typeTrans;
	}
	public void setTypeTrans(String typeTrans) {
		this.typeTrans = typeTrans;
	}

//	public Transaction(int accId, double openbal, String typeTrans, double deposit, String withdraw,
//			String fundTransfer, LocalDate date) {
//		super();
//		this.accId = accId;
//		this.openbal = openbal;
//		this.typeTrans = typeTrans;
//		Deposit = deposit;
//		Withdraw = withdraw;
//		FundTransfer = fundTransfer;
//		this.date = date;
//	}

//	public double getDeposit() {
//		return Deposit;
//	}
//
//	public void setDeposit(double amt) {
//		Deposit = amt;
//	}
//
//	public String getWithdraw() {
//		return Withdraw;
//	}
//
//	public void setWithdraw(String withdraw) {
//		Withdraw = withdraw;
//	}
//
//	public String getFundTransfer() {
//		return FundTransfer;
//	}
//
//	public void setFundTransfer(String fundTransfer) {
//		FundTransfer = fundTransfer;
//	}

	
	
	
	}
