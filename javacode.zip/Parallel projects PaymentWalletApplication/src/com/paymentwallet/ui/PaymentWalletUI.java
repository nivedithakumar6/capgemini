package com.paymentwallet.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.paymentwallet.bean.Payment;
import com.paymentwallet.bean.Transaction;
import com.paymentwallet.exception.InvalidException;
import com.paymentwallet.service.IPaymentWalletService;
import com.paymentwallet.service.PaymentWalletService;

public class PaymentWalletUI {

	static Scanner scan=new Scanner(System.in);
	static String name;
	static String mobile;
	static String email;
	static String dob;
	static String address;
	static String pan;
	static String type;
	static double openbal;
	static String h;
	static Transaction Trans=null;
	
	static boolean res=false;
	static IPaymentWalletService iser=null;
	
	public static void main(String[] args) throws InvalidException {
		
		do
		{
			System.out.println("Enter your choice between 1-6");
			System.out.println("1. Create Account\n2. Show Balance\n3. Deposit\n"
					+ "4. Withdraw\n5. Fund Transfer\n6. Print Transactions");
			int n=scan.nextInt();
			switch (n) {
			case 1:
				int finalAccId=createAccount();
				System.out.println("Employee information is stored");
				System.out.println("your account id is "+finalAccId);
				break;
			case 2:System.out.println("Enter the Account Id");
				int accId=scan.nextInt();
				showBalance(accId);
				
				break;
			case 3:
				System.out.println("Enter the Account Id");
				int accId1=scan.nextInt();
				System.out.println("Enter the amount to be deposited");
				double amt=scan.nextInt();
				deposit(accId1, amt);
				break;
			case 4:
				System.out.println("Enter the Account Id");
				int accId2=scan.nextInt();
				System.out.println("Enter the amount to be withdrawn");
				double amt2=scan.nextInt();
				withdraw(accId2,amt2);
				break;
			case 5:
				System.out.println("Enter the Account Id from which you want to transfer");
				int accId3=scan.nextInt();
				System.out.println("Enter the Account Id to which you want to transfer");
				int accId4=scan.nextInt();
				System.out.println("Enter the amount to be Transfered");
				double amt3=scan.nextInt();
				fundTransfer(accId3,accId4,amt3);
				break;
			case 6:
				printTransaction();
				break;

			default:
				System.out.println("Enter a valid choice");
				break;
				
				
				}
			System.out.println("Do you want to continue yes/No");
			h=scan.next();
			if(h.equals(null))
			{
				System.out.println("object is null, please enter the valid answer");
				h=scan.next();
			}
			if((h.equalsIgnoreCase("No")) || (h.equalsIgnoreCase("N")))
			{
				System.exit(0);
			}
		}while((h.equalsIgnoreCase("Yes")) || (h.equalsIgnoreCase("y")));
		
	}

	private static void printTransaction() {
//		System.out.println("enter the account id:");
//		int accId = scan.nextInt();
		iser.printTransaciton();
		
	}

	private static void fundTransfer(int accId3, int accId4, double amt3) {
		iser.fundTransfer(accId3, accId4, amt3);
		
	}

	private static void withdraw(int accId2, double amt2) {
		iser.withdraw(accId2, amt2);
	}

	public static void deposit(int accId1, double amt) {
		iser= new PaymentWalletService();
		Trans = new Transaction();
		iser.deposit(accId1, amt, Trans);
	}

	private static void showBalance(int accId) {
		iser.showBalanace(accId);
	}

	private static int createAccount() throws InvalidException {
		iser=new PaymentWalletService();
		do
		{
			try
			{
				System.out.println("Enter your Full name");
				name=scan.next();
				res=iser.validateName(name);
			}
			catch(InvalidException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter your Mobile number");
				mobile=scan.next();
				res=iser.validateMobile(mobile);
			}
			catch(InvalidException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter your Email Id");
				email=scan.next();
				res=iser.validateEmail(email);
			}
			catch(InvalidException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter your date of birth in dd/MM/yyyy");
				dob=scan.next();
				res=iser.validateDOB(dob);
			}
			catch(InvalidException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter your Address");
				address=scan.next();
				res=iser.validateAddress(address);
			}
			catch(InvalidException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter your pan");
				pan=scan.next();
				res=iser.validatePan(pan);
			}
			catch(InvalidException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter the type of account saving/current");
				type=scan.next();
				res=iser.validateType(type);
			}
			catch(InvalidException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		res=false;
		do
		{
			try
			{
				System.out.println("Enter the Account opening balance");
				openbal=scan.nextInt();
				res=iser.validateBalance(openbal);
			}
			catch(InvalidException e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(!res);
		
		Payment p=new Payment(name, mobile, email, dob, address, pan, type, openbal);
		Transaction c=new Transaction(openbal);
		int aid=iser.createAccount(p, c);
		return aid;
	}
	

}
