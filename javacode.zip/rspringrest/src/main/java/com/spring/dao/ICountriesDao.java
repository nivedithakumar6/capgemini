package com.spring.dao;

import java.util.List;

import com.spring.beans.Countries;


public interface ICountriesDao {

	public List<Countries> getAllCountries();
	public void addCountries(Countries countries);
	public Countries deleteCountries(int id);
	public Countries searchCountries(int id);
	
}
