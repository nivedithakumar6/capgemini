package com.spring.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.spring.beans.Countries;
import com.spring.db.CountriesDB;

@Repository
public class CountriesDaoImpl implements ICountriesDao {

	@Override
	public List<Countries> getAllCountries() {
		// TODO Auto-generated method stub
		return CountriesDB.getCountriesList();
	}

	@Override
	public void addCountries(Countries countries) {
		// TODO Auto-generated method stub
		CountriesDB.getCountriesList().add(countries);
	}

	@Override
	public Countries deleteCountries(int id) {
		// TODO Auto-generated method stub
		return CountriesDB.getCountriesList().remove(id);
	}

	@Override
	public Countries searchCountries(int id) {
		// TODO Auto-generated method stub
		return CountriesDB.getCountriesList().stream().filter(c->Integer.parseInt(c.getCountId())==id).findFirst().get();
	}

}
