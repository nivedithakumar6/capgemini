package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.beans.Countries;
import com.spring.dao.ICountriesDao;

@Service
public class CountriesServiceImpl implements ICountriesService{

	@Autowired
	ICountriesDao idao;
	
	@Override
	public List<Countries> getAllCountries() {
		// TODO Auto-generated method stub
		return idao.getAllCountries();
	}

	@Override
	public void addCountries(Countries countries) {
		// TODO Auto-generated method stub
		idao.addCountries(countries);
	}

	@Override
	public Countries deleteCountries(int id) {
		// TODO Auto-generated method stub
		return idao.deleteCountries(id);
	}

	@Override
	public Countries searchCountries(int id) {
		// TODO Auto-generated method stub
		return idao.searchCountries(id);
	}

}
