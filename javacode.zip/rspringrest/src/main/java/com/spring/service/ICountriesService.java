package com.spring.service;

import java.util.List;

import com.spring.beans.Countries;


public interface ICountriesService {
	
	public List<Countries> getAllCountries();
	public void addCountries(Countries countries);
	public Countries deleteCountries(int id);
	public Countries searchCountries(int id);
	

}
