package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.annotation.ApplicationScope;

import com.spring.beans.Countries;
import com.spring.service.ICountriesService;

@RestController
public class CountriesController {

	@Autowired
	ICountriesService serv;
	
		
	@RequestMapping(value="", method=RequestMethod.GET, headers="Accept=application/json")
		public List<Countries> getAllCountries(Model model){
			
			return serv.getAllCountries();
		}
		public void addCountries(Countries countries) {
			
		}
//		public Countries deleteCountries(int id) {
//			
//		}
//		public Countries searchCountries(int id) {
//			
//		}

	}


