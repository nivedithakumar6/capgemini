package com.spring.db;

import java.util.ArrayList;
import java.util.List;


import com.spring.beans.Countries;

public class CountriesDB {

	private static ArrayList<Countries> countriesList=new ArrayList<Countries>();
	
	static {
		countriesList.add(new Countries("1001","India","12000"));
		countriesList.add(new Countries("1002","Pakistan","13000"));
		countriesList.add(new Countries("1003","USA","14000"));
		countriesList.add(new Countries("1004","Australia","15000"));
	}
	
	public static ArrayList<Countries> getCountriesList()
	{
		return countriesList;
	}
	
	
	
	public static void setCountryList(
			List<Countries> countriesList) {

		CountriesDB.countriesList = (ArrayList<Countries>) countriesList;
	}
}
