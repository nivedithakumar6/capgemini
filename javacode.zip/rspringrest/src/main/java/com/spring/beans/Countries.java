package com.spring.beans;

public class Countries {
	
	private String countId;
	private String countName;
	private String countPop;
	
	public Countries() {
		super();
	}

	public Countries(String countId, String countName, String countPop) {
		super();
		this.countId = countId;
		this.countName = countName;
		this.countPop = countPop;
	}

	public String getCountId() {
		return countId;
	}

	public void setCountId(String countId) {
		this.countId = countId;
	}

	public String getCountName() {
		return countName;
	}

	public void setCountName(String countName) {
		this.countName = countName;
	}

	public String getCountPop() {
		return countPop;
	}

	public void setCountPop(String countPop) {
		this.countPop = countPop;
	}

	@Override
	public String toString() {
		return "Countries [countId=" + countId + ", countName=" + countName + ", countPop=" + countPop + "]";
	}
	
	

}
