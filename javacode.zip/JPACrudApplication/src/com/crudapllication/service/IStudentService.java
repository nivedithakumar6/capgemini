package com.crudapllication.service;

import com.crudapplication.entities.Student;

public interface IStudentService {

	Student getStudentById(int id);

	void addStudent(Student student);

	void removeStudent(Student student);

	void updateStudent(Student student);

	void commitTransaction();

	void beginTransaction();

}