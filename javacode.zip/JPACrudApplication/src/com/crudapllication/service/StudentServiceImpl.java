package com.crudapllication.service;

import com.crudapplication.dao.IStudentDao;
import com.crudapplication.dao.StudentDaoImpl;
import com.crudapplication.entities.Student;

public class StudentServiceImpl implements IStudentService {

	private IStudentDao dao;
	public StudentServiceImpl()
	{
		dao=new StudentDaoImpl();
	}
	@Override
	public Student getStudentById(int id) {
		
		Student student= dao.getStudentById(id);
		return student;
	}


	
	@Override
	public void addStudent(Student student) {
		dao.beginTransaction();
		dao.addStudent(student);
		dao.commitTransaction();
	}

	
	
	@Override
	public void removeStudent(Student student) {
		dao.beginTransaction();
		dao.removeStudent(student);
		dao.commitTransaction();
	}


	
	@Override
	public void updateStudent(Student student) {
		dao.beginTransaction();
		dao.updateStudent(student);
		dao.commitTransaction();
	}

	
	@Override
	public void commitTransaction() {
		dao.beginTransaction();
	}

	
	@Override
	public void beginTransaction() {
		
		dao.commitTransaction();
		
		
	}

}
