package com.crudapplication.client;

import com.crudapllication.service.IStudentService;
import com.crudapllication.service.StudentServiceImpl;
import com.crudapplication.entities.Student;

public class Client {
	
	public static void main(String[] args) {
		
		IStudentService serv= new StudentServiceImpl();
		Student student= new Student();
		
//		//add student
//		student.setName("Nancy");
//		serv.addStudent(student);
//		System.out.println("Added one student to database.");
		
		//get student details by Id
//		student=serv.getStudentById(9);
//		System.out.println("ID: "+student.getStudentId());
//		System.out.println("Name: "+student.getName());
//		
//		//update student by Id
//		student.setName("Sachin");
//		serv.updateStudent(student);
//		
//		//get student details by Id
//		student=serv.getStudentById(9);
//		System.out.println("ID: "+student.getStudentId());
//		System.out.println("Name: "+student.getName());
		
		//remove the record
		student=serv.getStudentById(9);
		serv.removeStudent(student);
		System.out.println("End of program...");
	}


}
