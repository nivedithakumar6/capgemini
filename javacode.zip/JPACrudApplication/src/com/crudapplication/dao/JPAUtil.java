package com.crudapplication.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.loader.custom.Return;

public class JPAUtil {
	
	public static EntityManager getEntityManager()
	{
		EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("JPA-PERSISTENCE-UNIT");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		return entityManager;
	}
}
