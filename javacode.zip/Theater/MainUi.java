package com.cg.ui;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import com.cg.bean.Theatre;
import com.cg.service.ITheatreService;
import com.cg.service.TheatreServiceImpl;

public class MainUi {

	static ITheatreService ith=null;
	 
	public static void main(String[] args) {
		System.out.println();
		ith=new TheatreServiceImpl();
		HashMap<Integer,Theatre> theatreList=ith.viewAllTheatres();
		Set r=theatreList.entrySet();
		r.stream().forEach(System.out::println);
		
		System.out.println("enter theatre id ");
		int id=new Scanner(System.in).nextInt();
		Theatre on=ith.updateTheatre(id);
		System.out.println("theatre info updated \n"+on);
	}

}




