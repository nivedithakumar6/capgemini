package com.cg.junit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

//import junit.framework.Assert;
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
//import org.junit.Ignore;
//import org.junit.Test;

public class TheatreTestCases {

	@BeforeEach
	public void helper(){
		System.out.println("i am a helper method-before");
	}
	@AfterEach
	public void helperAfter(){
		System.out.println("after");
	}
	@BeforeAll
	public static  void init(){
		System.out.println("initialization done");
	}
	@AfterAll
	public static void remove(){
		System.out.println("values are removed");
	}
	@Test
	public void getValue() {
		Assertions.assertEquals("hi", "hi");
	}
	
	//@Ignore
	@Disabled
	@Test
	public void get() {

	}

	@Test//(expected=ArithmeticException.class)
	public void display() {
		// System.out.println("in test1");
		int a = 34;
		if (a < 0) {
			Assertions.fail();
		} else {
			int c=10/0;
			//Assert.assertEquals(34, a);
		}

	}

}
