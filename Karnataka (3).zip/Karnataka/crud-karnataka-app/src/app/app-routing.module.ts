import { EditKarnaComponent } from './edit-karna/edit-karna.component';
import { AddKarnaComponent } from './add-karna/add-karna.component';
import { ListKarnaComponent } from './list-karna/list-karna.component';

import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LoginKarnaComponent } from './login-karna/login-karna.component';
export const routes:Routes=[
  {path:'', component:LoginKarnaComponent, pathMatch:'full'},
  {path:'login-karna',component:LoginKarnaComponent},
  {path:'list-karna',component:ListKarnaComponent},
  {path:'add-karna',component:AddKarnaComponent},
  {path:'edit-karna',component:EditKarnaComponent}
]


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  declarations: []
})
export class AppRoutingModule { }
