import { DataTableModule } from 'angular-6-datatable';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListKarnaComponent } from './list-karna/list-karna.component';
import { AddKarnaComponent } from './add-karna/add-karna.component';
import { EditKarnaComponent } from './edit-karna/edit-karna.component';
import { AppRoutingModule } from './app-routing.module';
import { LoginKarnaComponent } from './login-karna/login-karna.component';

@NgModule({
  declarations: [
    AppComponent,
    ListKarnaComponent,
    AddKarnaComponent,
    EditKarnaComponent,
    LoginKarnaComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    DataTableModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
