export class Karnataka{
    id?:number;
    name?:string;
    salary?:number;
    place?:string
}