import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Karnataka } from '../ModelFolder/karnataka.model';
import { KarnatakaService } from '../service/karnataka.service';

@Component({
  selector: 'app-list-karna',
  templateUrl: './list-karna.component.html',
  styleUrls: ['./list-karna.component.css']
})
export class ListKarnaComponent implements OnInit {

  karnataka: Karnataka[];
  filteredKarnataka: Karnataka[];

  _listFilter: string = '';
  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    console.log('set listFilter' + this._listFilter);
    this._listFilter = value;
    this.filteredKarnataka = this.listFilter ? this.performFilter(this.listFilter) : this.karnataka;
  }

  performFilter(filterBy: string): Karnataka[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.karnataka.filter((karnataka: Karnataka) =>
      karnataka.name.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }



  constructor(private karnaService: KarnatakaService, private router: Router) { }
  ngOnInit() {
    this.karnaService.getKarnataka()
      .subscribe((data: Karnataka[]) => {
      this.karnataka = data;
        //alert(data);
        this.filteredKarnataka = this.karnataka;
      });
  }

  deleteKarnataka(karnataka: Karnataka): void {
    this.karnaService.deleteKarnataka(karnataka.id)
      .subscribe(data => {

        this.karnataka = this.karnataka.filter(karna => karna != karnataka);
      })
  }
  editKarnataka(karnataka: Karnataka): void {
    localStorage.removeItem('editKarnaId');
    localStorage.setItem('editKarnaId', karnataka.id.toString());
    this.router.navigate(['edit-karna']);
  }

}
