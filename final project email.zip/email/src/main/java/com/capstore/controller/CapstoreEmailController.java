package com.capstore.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Customer;
import com.capstore.bean.Merchant;
import com.capstore.bean.Promos;
import com.capstore.bean.Schemes;
import com.capstore.exception.CustomerNotFound;
import com.capstore.service.CapstoreEmailService;

@RestController
@RequestMapping("/capstore")
public class CapstoreEmailController {

	@Autowired
	CapstoreEmailService cser;
	
	//Project operations

	//verify the customer by ID
	@RequestMapping(value = "/admin/verifyCustomer/{custid}", method = RequestMethod.GET)
	public Optional<Customer> VerifyCustomerById(@PathVariable int custid) throws CustomerNotFound {
		Optional<Customer> customer = this.cser.VerifyCustomerById(custid);
		if(!customer.isPresent())
			throw new CustomerNotFound("Customer is Not verified!");
		return customer;
	}
	
	//verify the Merchant by ID
	@RequestMapping(value = "/admin/verifyMerchant/{merchantid}", method = RequestMethod.GET)
	public Optional<Merchant> VerifyMerchantById(@PathVariable int merchantid) throws CustomerNotFound {
		Optional<Merchant> merchant = this.cser.VerifyMerchantById(merchantid);
		if(!merchant.isPresent())
			throw new CustomerNotFound("Merchant is Not verified!");
		return merchant;
	}
	
	//send Invitation to customer
	@GetMapping(value = "/admin/sendInvitationCustomer/{custemail}" , produces= {"application/json","application/xml" })
	public List<String> SendInvitationCustomer(@PathVariable String custemail) throws CustomerNotFound{
		cser.validationCustomerEmail(custemail);		
		List<String> sendInv=new ArrayList<String>();
		sendInv.add("Welcome To Capstore, You are invited to Capstore, Your Customer ID is "+custemail);
		return sendInv;
	}
	
	//send Invitation to Merchant
	@RequestMapping(value = "/admin/sendInvitationMerchant/{merchantemail}", method = RequestMethod.GET)
	public List<String> SendInvitationMerchant(@PathVariable String merchantemail) throws CustomerNotFound{
		cser.validationMerchantEmail(merchantemail);
		List<String> sendInv=new ArrayList<String>();
		sendInv.add("Welcome To Capstore, You are invited to Capstore, Your Merchant ID is "+merchantemail);
		return sendInv;
	}
	
	//sending promos to customer
	@RequestMapping(value = "sendpromos/admin/customer/{custemail}", method = RequestMethod.GET)
	public List<Promos> sendPromosCustomer(@PathVariable String custemail) throws CustomerNotFound{
		cser.validationCustomerEmail(custemail);
		return this.cser.sendPromosCustomer(custemail);
	}
	
	//sending promos to Merchant
	@RequestMapping(value = "sendpromos/admin/merchant/{merchantemail}", method = RequestMethod.GET)
		public List<Promos> sendPromosMerchants(@PathVariable String merchantemail) throws CustomerNotFound{
			cser.validationMerchantEmail(merchantemail);
			return this.cser.sendPromosMerchants(merchantemail);
	}
	
	//sending Schemes to customer and Merchant
	@RequestMapping(value = "sendschemes/admin/customer/{custemail}", method = RequestMethod.GET)
		public List<Schemes> sendSchemesCustomer(@PathVariable String custemail) throws CustomerNotFound{
		cser.validationCustomerEmail(custemail);
		return this.cser.sendSchemesCustomer(custemail);
	}
	
	//sending Schemes to customer and Merchant
		@RequestMapping(value = "sendschemes/admin/merchant/{merchantemail}", method = RequestMethod.GET)
		public List<Schemes> sendSchemes(@PathVariable String merchantemail) throws CustomerNotFound{
			cser.validationMerchantEmail(merchantemail);
			return this.cser.sendSchemesMerchant(merchantemail);
		}
	
	//Merchants Sending response to admin
	@RequestMapping(value = "/merchant/responsetoadmin", method = RequestMethod.PUT, 
		consumes = MediaType.APPLICATION_JSON_VALUE, 
		produces = MediaType.APPLICATION_JSON_VALUE)
		public Customer MerchantResponse(@RequestBody Customer customer) {
			return this.cser.MerchantResponse(customer);
	}	
	
	//Admin forwarding the Merchants data to Customer
	@RequestMapping(value = "/admin/forawardResponseCustomer/{custid}/{custemail}", method = RequestMethod.GET)
	public Optional<Customer> VerifyCustomerById(@PathVariable int custid,@PathVariable String custemail) throws CustomerNotFound {
		
		Optional<Customer> customer = this.cser.VerifyCustomerById(custid);
		if(!customer.isPresent())
			throw new CustomerNotFound("Customer ID is Incorrect");
		return customer;
	}
	
	
	
	
	
	
		//Add Promos
		@RequestMapping(value="/addpromos", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
		public Promos addPromos(@RequestBody Promos promos) {
			return this.cser.addPromos(promos);
		}
			
		//Add Schemes
		@RequestMapping(value="/addschemes", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
		public Schemes addSchemes(@RequestBody Schemes schemes) {
			return this.cser.addSchemes(schemes);
		}
		
		//Add Customer
		@RequestMapping(value="/addcustomer", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
		public Customer addCustomer(@RequestBody Customer customer) {
			return this.cser.addCustomer(customer);
		}
						
		//Get All Customer details
		@RequestMapping(value = "/getcustomer", method = RequestMethod.GET)
		public List<Customer> getCustomer() {
			return this.cser.getCustomer();
		}
		
		//Add Merchant
		@RequestMapping(value="/addmerchant", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
		public Merchant addMerchant(@RequestBody Merchant merchant) {
			return this.cser.addMerchant(merchant);
		}
								
		//Get All Customer details
		@RequestMapping(value = "/getmerchant", method = RequestMethod.GET)
		public List<Merchant> getMerchant() {
			return this.cser.getMerchant();
		}
		
		//sending promos
		@RequestMapping(value = "/sendpromos", method = RequestMethod.GET)
		public List<Promos> sendPromos(){
			
			return this.cser.sendPromos();
		}
		 
		//sending Schemes
				@RequestMapping(value = "/sendschemes", method = RequestMethod.GET)
				public List<Schemes> sendSchemes() throws CustomerNotFound{
					
					return this.cser.sendSchemes();
				}
}


