package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.capstore.bean.Customer;
import com.capstore.bean.Merchant;
import com.capstore.bean.Promos;
import com.capstore.bean.Schemes;
import com.capstore.dao.ICustomerDao;
import com.capstore.dao.IMerchantDao;
import com.capstore.dao.IPromosDao;
import com.capstore.dao.ISchemesDao;
import com.capstore.exception.CustomerNotFound;

@Service
public class CapstoreEmailService {

	@Autowired
	IPromosDao promoDao;
	
	@Autowired
	ISchemesDao schemeDao;
	
	@Autowired
	ICustomerDao custDao;
	
	@Autowired
	IMerchantDao merchantDao;
	
	//Project operations
	
	//verify customer and admin forwarding email to Customer
	public Optional<Customer> VerifyCustomerById(int custid) {
		return this.custDao.findById(custid);
	}
	
	//verify Merchant and admin forwarding email to Merchant
	public Optional<Merchant> VerifyMerchantById(int merchantid) {
		return this.merchantDao.findById(merchantid);
	}
	
	//sending invitation to customer
	public List<Customer> SendInvitationCustomer(String custemail) {
		return this.custDao.findAll();
	}
	
	//sending invitation to merchant
	public List<Merchant> SendInvitationMerchant(String merchantemail) {
		return this.merchantDao.findAll();
	}
	
	//sending promos to Customer 
	public List<Promos> sendPromosCustomer(String custemail) {
        return this.promoDao.findAll();
    }
	
	//sending promos to Merchants
		public List<Promos> sendPromosMerchants(String merchantemail) {
	        return this.promoDao.findAll();
	    }
	
	//Sending Schemes to Customer and Merchants
	public List<Schemes> sendSchemesCustomer(String custemail) {
        return this.schemeDao.findAll();
    }
	
	//Sending Schemes to Customer and Merchants
	public List<Schemes> sendSchemesMerchant(String merchantemail) {
	    return this.schemeDao.findAll();
	}
	
	//Merchants Sending response to admin for Customer
	public Customer MerchantResponse(Customer customer) {
		return this.custDao.save(customer);
	}
	
	//Merchants Sending response to admin for Customer
	public Merchant MerchantResponse(Merchant merchant) {
		return this.merchantDao.save(merchant);
	}
	
	
	
	
	
	//Promos Section
	
	public Promos addPromos(Promos promos) {
		return this.promoDao.save(promos);
	}
	
	//Schemes Section
	
	public Schemes addSchemes(Schemes schemes) {
		return this.schemeDao.save(schemes);
	}
	
	//Customer Section
	
	public Customer addCustomer(Customer customer) {
		return this.custDao.save(customer);
	}
	
	public List<Customer> getCustomer() {
        return this.custDao.findAll();
    }

	//Merchant Section

	public Merchant addMerchant(Merchant merchant) {
		return this.merchantDao.save(merchant);
	}
	
	public List<Merchant> getMerchant() {
        return this.merchantDao.findAll();
    }


	//validate customer email
	public  void validationCustomerEmail(String custemail) throws CustomerNotFound {
		boolean status=false;
		List<Customer> customers=getCustomer();
		List<Customer> customer= new ArrayList<>();
		for(Customer cust:customers) {
			if((cust.getCustEmail().equals(custemail))) {
				status=true;
				customer.add(cust);
			}
			if(status==false) {
				throw new CustomerNotFound("Customer Email ID does not exists");
			}
		}
	}	
	
	//validate Merchant email
		public  void validationMerchantEmail(String merchantemail) throws CustomerNotFound {
			boolean status=false;
			List<Merchant> merchants=getMerchant();
			List<Merchant> merchant= new ArrayList<>();
			for(Merchant mer:merchants) {
				if((mer.getMerchantEmail().equals(merchantemail))) {
					status=true;
					merchant.add(mer);
				}
				if(status==false) {
					throw new CustomerNotFound("Merchant Email ID does not exists");
				}
			}
		}

		public List<Promos> sendPromos() {
			return this.promoDao.findAll();
		}
		public List<Schemes> sendSchemes() {
			return this.schemeDao.findAll();
		}
	
}
