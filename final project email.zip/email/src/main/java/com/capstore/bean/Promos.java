package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "PROMOS")
public class Promos {
	
		//assigning column name
		@Column(name = "PROMOID",length = 20)
	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Integer promoid;
		
		@Column(name = "PROMOCODE")
	    private String promocode;
		
		@Column(name = "PROMONAME")
	    private String promoname;
		
		@Column(name = "PROMODESCRIPTION")
	    private String promodescription;

		
		
		public String getPromocode() {
			return promocode;
		}

		public void setPromocode(String promocode) {
			this.promocode = promocode;
		}

		public Integer getPromoid() {
			return promoid;
		}

		public void setPromoid(Integer promoid) {
			this.promoid = promoid;
		}

		public String getPromoname() {
			return promoname;
		}

		public void setPromoname(String promoname) {
			this.promoname = promoname;
		}

		public String getPromodescription() {
			return promodescription;
		}

		public void setPromodescription(String promodescription) {
			this.promodescription = promodescription;
		}


		public Promos() {
			
		}

		public Promos(Integer promoid, String promocode, String promoname, String promodescription) {
			
			this.promoid = promoid;
			this.promocode = promocode;
			this.promoname = promoname;
			this.promodescription = promodescription;
		}

		public Promos(String promocode, String promoname, String promodescription) {
			
			this.promocode = promocode;
			this.promoname = promoname;
			this.promodescription = promodescription;
		}

		
}
