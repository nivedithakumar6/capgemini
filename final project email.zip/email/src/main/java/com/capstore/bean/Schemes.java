package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "SCHEMES")
public class Schemes {
	
		//assigning column name
		@Column(name = "SCHEMEID",length = 20)
	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Integer schemeid;
		
		@Column(name = "SCHEMECODE")
	    private String schemecode;
		
		@Column(name = "SCHEMENAME")
	    private String schemename;
		
		@Column(name = "SCHEMEDESCRIPTION")
	    private String schemedescription;

		
		
		public String getSchemecode() {
			return schemecode;
		}

		public void setSchemecode(String schemecode) {
			this.schemecode = schemecode;
		}

		public Integer getSchemeid() {
			return schemeid;
		}

		public void setSchemeid(Integer schemeid) {
			this.schemeid = schemeid;
		}

		public String getSchemename() {
			return schemename;
		}

		public void setSchemename(String schemename) {
			this.schemename = schemename;
		}

		public String getSchemedescription() {
			return schemedescription;
		}

		public void setSchemedescription(String schemedescription) {
			this.schemedescription = schemedescription;
		}

		public Schemes() {
			
		}

		public Schemes(Integer schemeid, String schemecode, String schemename, String schemedescription) {
			
			this.schemeid = schemeid;
			this.schemecode = schemecode;
			this.schemename = schemename;
			this.schemedescription = schemedescription;
		}

		public Schemes(String schemecode, String schemename, String schemedescription) {
			
			this.schemecode = schemecode;
			this.schemename = schemename;
			this.schemedescription = schemedescription;
		}

		
}
