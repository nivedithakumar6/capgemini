package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MERCHANT")
public class Merchant {

	//assigning column name
	@Column(name = "MERCHANTID")
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer merchantid;
					
	@Column(name = "MERCHANTNAME")
	private String merchantname;
			
	@Column(name = "MERCHANTEMAIL")
	private String merchantEmail;
			
	@Column(name = "MAPPLIEDPROMOCODE")
	private String mpromocode;
			
	@Column(name = "MAPPLIEDSCHEMECODE")
	private String mschemecode;

	public Integer getMerchantid() {
		return merchantid;
	}

	public void setMerchantid(Integer merchantid) {
		this.merchantid = merchantid;
	}

	public String getMerchantname() {
		return merchantname;
	}

	public void setMerchantname(String merchantname) {
		this.merchantname = merchantname;
	}

	public String getMerchantEmail() {
		return merchantEmail;
	}

	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}

	public String getMpromocode() {
		return mpromocode;
	}

	public void setMpromocode(String mpromocode) {
		this.mpromocode = mpromocode;
	}

	public String getMschemecode() {
		return mschemecode;
	}

	public void setMschemecode(String mschemecode) {
		this.mschemecode = mschemecode;
	}

	public Merchant(Integer merchantid, String merchantname, String merchantEmail, String mpromocode,
			String mschemecode) {
		super();
		this.merchantid = merchantid;
		this.merchantname = merchantname;
		this.merchantEmail = merchantEmail;
		this.mpromocode = mpromocode;
		this.mschemecode = mschemecode;
	}

	public Merchant() {
		super();
	}

	public Merchant(String merchantname, String merchantEmail, String mpromocode, String mschemecode) {
		super();
		this.merchantname = merchantname;
		this.merchantEmail = merchantEmail;
		this.mpromocode = mpromocode;
		this.mschemecode = mschemecode;
	}
	
	
	
}
