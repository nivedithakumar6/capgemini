package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CUSTOMER")
public class Customer {
	
		//assigning column name
		@Column(name = "CUSTID")
	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Integer custid;
				
		@Column(name = "CUSTNAME")
	    private String custname;
		
		@Column(name = "CUSTEMAIL")
	    private String custEmail;
		
		@Column(name = "APPLIEDPROMOCODE")
	    private String promocode;
		
		@Column(name = "APPLIEDSCHEMECODE")
	    private String schemecode;

		public Integer getCustid() {
			return custid;
		}

		public void setCustid(Integer custid) {
			this.custid = custid;
		}

		public String getCustname() {
			return custname;
		}

		public void setCustname(String custname) {
			this.custname = custname;
		}

		public String getCustEmail() {
			return custEmail;
		}

		public void setCustEmail(String custEmail) {
			this.custEmail = custEmail;
		}

		
		
		public String getPromocode() {
			return promocode;
		}

		public void setPromocode(String promocode) {
			this.promocode = promocode;
		}

		public String getSchemecode() {
			return schemecode;
		}

		public void setSchemecode(String schemecode) {
			this.schemecode = schemecode;
		}

		public Customer() {
			
		}

		public Customer(Integer custid, String custname, String custEmail, String promocode, String schemecode) {
			super();
			this.custid = custid;
			this.custname = custname;
			this.custEmail = custEmail;
			this.promocode = promocode;
			this.schemecode = schemecode;
		}

		public Customer(String custname, String custEmail, String promocode, String schemecode) {
			super();
			this.custname = custname;
			this.custEmail = custEmail;
			this.promocode = promocode;
			this.schemecode = schemecode;
		}

		

}
