// Author:"Niveditha K"
// Created on: "24/05/2019"
// Modified on:"Nil"
// Class Name: "EmployeeNotFoundException"
// Purpose: "creating the Exceptions class to display to the employees"

package com.capstore.exception;

public class CustomerNotFound extends Exception {
//default constructor
	public CustomerNotFound() {
		super();

	}

	public CustomerNotFound(String message) {
		super(message);

	}
	 
}
